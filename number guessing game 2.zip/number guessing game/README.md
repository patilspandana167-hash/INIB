# 🎯 Number Guessing Game (Java Swing GUI & CLI)
### **OASIS INFOBYTE INTERNSHIP — TASK 1**

![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![Swing](https://img.shields.io/badge/GUI-Java%20Swing-blue?style=for-the-badge)
![Status](https://img.shields.io/badge/Build-Passing-brightgreen?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-purple?style=for-the-badge)

---

## 📌 1. Project Overview & Objective

This project is a complete, polished, and professional implementation of **Task 1: Number Guessing Game** for the **Infobyte Internship Program**. 

The application challenges players to guess a randomly generated secret number within a limited number of attempts. It provides instant high/low feedback, robust input validation, dynamic scoring, session statistics tracking, and replay functionality.

Built with **Java SE** and a custom-designed **Java Swing Graphical User Interface (GUI)**, the project features a sleek dark-navy gradient theme, rounded card containers, real-time attempt progress bars, and an animated victory confetti celebration without requiring any external libraries or dependencies.

---

## 🏆 2. Infobyte Task 1 Requirement Matrix

| # | Task Requirement | Implementation Status | Implementation Details |
|---|---|---|---|
| **1** | **Game Setup** | ✅ Fully Implemented | Generates a random number in specified range using `ThreadLocalRandom`. Range updates dynamically per difficulty (1–50, 1–100, 1–200). Secret number remains strictly concealed until the round concludes. |
| **2** | **User Input & Feedback** | ✅ Fully Implemented | Evaluates user guesses and returns exact prompts: *"Too high! Try a smaller number."*, *"Too low! Try a larger number."*, and celebratory feedback upon winning. Rejects empty, whitespace, non-numeric, duplicate, and out-of-range inputs safely without crashing. |
| **3** | **Limited Attempts** | ✅ Fully Implemented | Constrains guesses to 7 attempts per round (Medium standard), 10 attempts (Easy), or 6 attempts (Hard). Displays real-time attempts used/remaining via both text and a colored progress bar. Ends round and reveals the secret number upon exhaustion. |
| **4** | **Win Condition & Scoring** | ✅ Fully Implemented | Triggers celebratory visual feedback and confetti particle physics on victory. Computes dynamic scores based on remaining attempts and difficulty multipliers. Tracks session-wide best score and win rate. |
| **5** | **Replay Option** | ✅ Fully Implemented | Features one-click **"Play Again"** and **"Exit Game"** controls. Seamlessly resets round variables, clears guess history, and generates a fresh random number without restarting the JVM. |

---

## ✨ 3. Key Features & Visual Design

- 🧠 **Binary Search Space Advisor**: Dynamically calculates the narrowed candidate range `[min to max]` and recommends the mathematically optimal $O(\log N)$ guess after every clue.
- 💡 **Educational Clue / Hint System**: Provides mathematical hints on demand (Parity: Even/Odd, Divisibility by 3/5/7, Digit Sums, and Prime vs Composite numbers).
- 🏆 **Persistent Local Leaderboard**: Automatically appends match outcomes to a local `leaderboard.csv` file and displays a Hall of Fame ranking dialog.
- 📄 **Formal Performance Report Exporter**: Generates a timestamped `.txt` evaluation report with candidate name, efficiency ratings, accuracy %, and session breakdown.
- 👤 **Customizable Player Profile**: Allows candidates to set and edit their name for personalized reports and records.
- 🎨 **Modern Dark Navy UI**: Multi-stop gradient background (`#0B0F19` to `#1E1B4B`) with semi-transparent glassmorphism card panels and subtle glowing borders.
- 🎯 **Target Range Display**: Prominently displays the active number range (e.g., `Target Range: 1 - 100`).
- 📊 **Dynamic Attempts Progress Bar**: Smoothly shifts color from **Emerald Green** (safe) to **Amber** (warning) to **Crimson** (critical) as attempts deplete.
- 💬 **Color-Coded Feedback Badges**:
  - 📉 High Guesses: Amber Warning Badge
  - 📈 Low Guesses: Cyan Info Badge
  - 🎉 Winning Guess: Emerald Victory Badge
  - 💀 Game Over: Crimson Loss Badge
  - ⚠️ Invalid Input: Coral Alert Badge
- 📜 **Deduction History Tracker**: Displays previous guesses made in the current round (e.g., `50 • 25 • 37`) to help players make strategic guesses.
- 🎊 **Built-in Confetti Celebration**: 100+ simulated physics particles flutter down the screen upon victory using a 60 FPS Swing Timer—100% pure Java with zero external dependencies.
- ⚙️ **Three Difficulty Modes**:
  - **Easy**: Numbers from `1 - 50` | `10 Attempts` | `1.0x Score Multiplier`
  - **Medium**: Numbers from `1 - 100` | `7 Attempts` | `1.5x Score Multiplier` (Standard)
  - **Hard**: Numbers from `1 - 200` | `6 Attempts` | `2.5x Score Multiplier`
- 📈 **Session Performance Statistics**: Tracks Total Games Played, Total Wins, Total Losses, Win Percentage, Current Score, and Best Score.
- ⌨️ **Keyboard Navigation**: Press **Enter** to submit guesses; press **Ctrl + N** to trigger a new round instantly.
- 💻 **Dual Execution Modes**: Launches the Swing GUI by default, with an optional `--cli` flag for head-to-head terminal execution.
- 🌐 **Interactive Web Edition (`index.html`)**: Fully playable browser companion matching the Swing design with synthesized Web Audio sound effects.

---

## 🗂️ 4. Project Directory Structure

```
number-guessing-game/
├── .gitignore                   # Ignores compiled binaries and IDE configs
├── README.md                    # Comprehensive project documentation
├── index.html                   # Interactive browser playable edition
├── leaderboard.csv              # Persistent local CSV leaderboard records
├── Internship_Task1_Report.txt  # Generated formal evaluation report
├── bin/                         # Compiled .class bytecode (generated on build)
└── src/
    ├── Difficulty.java          # Enum defining Easy, Medium, and Hard configurations
    ├── GameLogic.java           # Core game mechanics, search space tracking, and hints
    ├── GameLogicTest.java       # Automated unit test suite (158 test assertions)
    ├── GameRecord.java          # Individual match data transfer object
    ├── GameStats.java           # Session statistics and best score tracker
    ├── GuessResult.java         # Encapsulates round feedback, state, and score
    ├── Main.java                # Main entry point (launches GUI or CLI mode)
    ├── NumberGuessingGame.java  # Modern Java Swing GUI window and controller
    ├── ScorePersistence.java   # CSV persistence and report file exporter
    └── UIComponents.java        # Custom Swing widgets, colors, gradients, and confetti
```

---

## 🛠️ 5. Prerequisites & Requirements

- **Java Development Kit (JDK)**: Version 8 or higher (Tested and certified on **Java 21 LTS**).
- **Operating System**: Windows, macOS, or Linux.
- **Dependencies**: None. Standard Java SE Runtime only.

Check your installed Java version:
```bash
java -version
javac -version
```

---

## 🚀 6. How to Compile and Run

### Option A: From Command Line / Terminal (Recommended)

1. Open a terminal or PowerShell in the project root directory:
   ```bash
   cd "number guessing game"
   ```

2. Compile all source files into the `bin` directory:
   ```bash
   javac -encoding UTF-8 -d bin src/*.java
   ```

3. **Launch the Graphical User Interface (GUI)**:
   ```bash
   java -cp bin Main
   ```

4. *(Optional)* **Launch Terminal / Console Mode**:
   ```bash
   java -cp bin Main --cli
   ```

5. **Run the Automated Test Suite (150 Automated Assertions)**:
   ```bash
   java -cp bin GameLogicTest
   ```

---

### Option B: Running in Visual Studio Code

1. Open the project folder in VS Code (`File` > `Open Folder...`).
2. Ensure the **Extension Pack for Java** is installed.
3. Open `src/Main.java`.
4. Click **Run** or press `F5` to start the GUI.

---

### Option C: Running in IntelliJ IDEA

1. Open IntelliJ IDEA and select **Open** > choose the project folder.
2. In Project Structure (`File` > `Project Structure`), ensure JDK 8+ is selected.
3. Mark `src` as the **Sources Root** (Right-click `src` > `Mark Directory as` > `Sources Root`).
4. Open `src/Main.java` and click the green **Run** arrow next to `public static void main`.

---

## 🧠 7. Core Mechanics Explained

### A. Random Secret Number Generation
```java
this.secretNumber = ThreadLocalRandom.current().nextInt(
    difficulty.getMinRange(),
    difficulty.getMaxRange() + 1
);
```
- Uses `java.util.concurrent.ThreadLocalRandom` for thread-safe, cryptographically uniform random integer generation.
- Generates numbers between `minRange` and `maxRange` inclusive.
- Concealed privately inside `GameLogic` and never revealed before the round ends.

### B. Input Validation Strategy
Every guess string is validated through 4 distinct filter gates before consuming an attempt:
1. **Empty Check**: Rejects blank strings or whitespace.
2. **Numeric Check**: Catches `NumberFormatException` for alphabetic/special characters without crashing.
3. **Range Check**: Ensures guesses remain within `[minRange, maxRange]`.
4. **Duplicate Check**: Prevents penalty if the player mistakenly enters the same number twice.
*Non-valid inputs return friendly alerts and do NOT decrement attempts!*

### C. Scoring Formula
$$Score = \max(0, \lfloor(AttemptsRemaining + 1) \times 100 \times Multiplier\rfloor)$$
- **Fewer attempts = higher score**: Guessing on Attempt 1 awards maximum points plus a **Bullseye Bonus (+500 pts)**.
- **Difficulty Multipliers**: Easy = `1.0x`, Medium = `1.5x`, Hard = `2.5x`.
- **Losses**: Exhausting attempts awards `0 pts`.

---

## 📸 8. Screenshots

> *Placeholder: Add your application screenshots here for your portfolio and internship report.*

| Modern Dark GUI Gameplay | Celebratory Victory & Confetti |
|:---:|:---:|
| `![Gameplay Screenshot](screenshots/gameplay.png)` | `![Victory Screenshot](screenshots/victory.png)` |

---

## 👨‍💻 9. Author & Internship Details

- **Intern Name**: [Your Full Name]
- **Internship Domain**: Java Development
- **Organization**: OASIS INFOBYTE
- **Task**: Task 1 — Number Guessing Game
- **Batch**: [Your Internship Month / Year]
- **LinkedIn**: [Your LinkedIn Profile URL]
- **GitHub**: [Your GitHub Profile URL]

---

## 📜 10. License

This project is open-source and available under the [MIT License](LICENSE). Free to use for academic, internship, and educational purposes.
