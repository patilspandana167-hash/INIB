/**
 * Represents the outcome of a player's guess attempt.
 * Encapsulates status, user feedback message, attempts used/remaining,
 * and score information.
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public class GuessResult {

    public enum Status {
        TOO_HIGH,
        TOO_LOW,
        CORRECT,
        GAME_OVER_LOST,
        INVALID_EMPTY,
        INVALID_NON_NUMERIC,
        OUT_OF_RANGE,
        ALREADY_GUESSED
    }

    private final Status status;
    private final String message;
    private final int guess;
    private final int attemptsUsed;
    private final int attemptsRemaining;
    private final int pointsAwarded;
    private final boolean roundOver;
    private final boolean roundWon;
    private final int revealedSecretNumber; // -1 if not game over

    public GuessResult(Status status, String message, int guess, int attemptsUsed, 
                       int attemptsRemaining, int pointsAwarded, boolean roundOver, 
                       boolean roundWon, int revealedSecretNumber) {
        this.status = status;
        this.message = message;
        this.guess = guess;
        this.attemptsUsed = attemptsUsed;
        this.attemptsRemaining = attemptsRemaining;
        this.pointsAwarded = pointsAwarded;
        this.roundOver = roundOver;
        this.roundWon = roundWon;
        this.revealedSecretNumber = revealedSecretNumber;
    }

    public Status getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public int getGuess() {
        return guess;
    }

    public int getAttemptsUsed() {
        return attemptsUsed;
    }

    public int getAttemptsRemaining() {
        return attemptsRemaining;
    }

    public int getPointsAwarded() {
        return pointsAwarded;
    }

    public boolean isRoundOver() {
        return roundOver;
    }

    public boolean isRoundWon() {
        return roundWon;
    }

    public int getRevealedSecretNumber() {
        return revealedSecretNumber;
    }

    public boolean isInputError() {
        return status == Status.INVALID_EMPTY || 
               status == Status.INVALID_NON_NUMERIC || 
               status == Status.OUT_OF_RANGE || 
               status == Status.ALREADY_GUESSED;
    }
}
