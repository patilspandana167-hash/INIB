import java.util.Scanner;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Main entry point for the Number Guessing Game.
 * Infobyte Internship Task 1.
 * 
 * Launches the modern Swing GUI by default.
 * Also includes an optional interactive CLI fallback when run with --cli or --console.
 */
public class Main {

    public static void main(String[] args) {
        // Check if user requested console / terminal mode
        if (args.length > 0 && (args[0].equalsIgnoreCase("--cli") || args[0].equalsIgnoreCase("--console"))) {
            runConsoleMode();
            return;
        }

        // Enable high-DPI font anti-aliasing
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        // Use system look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Fall back gracefully to standard Swing L&F
        }

        // Launch modern GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            NumberGuessingGame gameFrame = new NumberGuessingGame();
            gameFrame.setVisible(true);
        });
    }

    /**
     * Optional interactive Console / Terminal mode for environments without a display
     * or for evaluators who want to test CLI execution.
     * Shares the exact same GameLogic and GameStats classes.
     */
    private static void runConsoleMode() {
        Scanner scanner = new Scanner(System.in);
        GameStats stats = new GameStats();
        boolean keepPlaying = true;

        System.out.println("==================================================");
        System.out.println("       INFOBYTE INTERNSHIP: TASK 1");
        System.out.println("          NUMBER GUESSING GAME (CLI)");
        System.out.println("==================================================");

        while (keepPlaying) {
            System.out.println("\nSelect Difficulty Level:");
            System.out.println("1. Easy   (Range: 1 - 50,  10 Attempts)");
            System.out.println("2. Medium (Range: 1 - 100, 7 Attempts) [Standard]");
            System.out.println("3. Hard   (Range: 1 - 200, 6 Attempts)");
            System.out.print("Enter choice (1-3, default 2): ");

            if (!scanner.hasNextLine()) break;
            String diffInput = scanner.nextLine().trim();
            Difficulty diff = Difficulty.MEDIUM;
            if (diffInput.equals("1")) diff = Difficulty.EASY;
            else if (diffInput.equals("3")) diff = Difficulty.HARD;

            GameLogic logic = new GameLogic(diff);
            System.out.printf("\n[New Round Started] %s\n", diff.getDescription());
            System.out.println("--------------------------------------------------");

            while (!logic.isGameOver()) {
                System.out.printf("Attempts Remaining: %d / %d\n", logic.getRemainingAttempts(), logic.getMaxAttempts());
                System.out.print("Enter your guess: ");
                if (!scanner.hasNextLine()) {
                    keepPlaying = false;
                    break;
                }
                String input = scanner.nextLine();

                GuessResult result = logic.submitGuess(input);
                System.out.println(">> " + result.getMessage());

                if (result.isRoundOver()) {
                    stats.recordRound(result.isRoundWon(), result.getPointsAwarded());
                    System.out.println("--------------------------------------------------");
                    System.out.printf("Round Over! Score: %d pts | Session Best: %d pts\n",
                            result.getPointsAwarded(), stats.getBestScore());
                    System.out.printf("Session Stats: %d Games | %d Wins | %d Losses | Win Rate: %s\n",
                            stats.getTotalGamesPlayed(), stats.getTotalWins(), stats.getTotalLosses(),
                            stats.getFormattedWinPercentage());
                }
                System.out.println();
            }

            if (!keepPlaying) break;
            System.out.print("Do you want to play another round? (y/n): ");
            if (!scanner.hasNextLine()) break;
            String replayChoice = scanner.nextLine().trim().toLowerCase();
            if (!replayChoice.startsWith("y")) {
                keepPlaying = false;
            }
        }

        System.out.println("\nThank you for playing the Number Guessing Game!");
        System.out.printf("Final Session Best Score: %d pts\n", stats.getBestScore());
        scanner.close();
    }
}
