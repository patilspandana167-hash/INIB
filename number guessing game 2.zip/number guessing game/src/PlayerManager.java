import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages player profiles and active player selection for solo and 2-player modes.
 * Persists registered players to local players.txt.
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public class PlayerManager {

    private static final String PLAYERS_FILE = "players.txt";
    private final List<String> playerList;
    private String activePlayer;

    public PlayerManager() {
        this.playerList = new ArrayList<>();
        loadPlayers();
        if (playerList.isEmpty()) {
            playerList.add("Spandana");
            playerList.add("Player 1");
            playerList.add("Player 2");
            savePlayers();
        }
        this.activePlayer = playerList.get(0);
    }

    public synchronized void addPlayer(String name) {
        if (name == null || name.trim().isEmpty()) return;
        String clean = name.trim();
        if (!playerList.contains(clean)) {
            playerList.add(clean);
            savePlayers();
        }
        this.activePlayer = clean;
    }

    public synchronized List<String> getPlayers() {
        return new ArrayList<>(playerList);
    }

    public synchronized String getActivePlayer() {
        return activePlayer;
    }

    public synchronized void setActivePlayer(String name) {
        if (name != null && playerList.contains(name.trim())) {
            this.activePlayer = name.trim();
        }
    }

    private synchronized void loadPlayers() {
        File f = new File(PLAYERS_FILE);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !playerList.contains(line)) {
                    playerList.add(line);
                }
            }
        } catch (IOException ignored) {}
    }

    private synchronized void savePlayers() {
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(PLAYERS_FILE), StandardCharsets.UTF_8))) {
            for (String p : playerList) {
                pw.println(p);
            }
        } catch (IOException ignored) {}
    }
}
