import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * Modern Swing UI design components and styling system.
 * Implements smooth gradients, rounded card containers, custom buttons,
 * responsive indicators, and celebratory confetti animations.
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public final class UIComponents {

    private UIComponents() {}

    // ==========================================
    // THEME PALETTE
    // ==========================================
    public static final class Colors {
        public static final Color BG_TOP = new Color(7, 9, 19);           // Obsidian Space
        public static final Color BG_MID = new Color(15, 16, 38);          // Deep Aurora Nebula
        public static final Color BG_BOTTOM = new Color(22, 18, 51);       // Rich Indigo Velvet

        public static final Color CARD_BG = new Color(15, 20, 38, 220);    // Frosted Dark Glass
        public static final Color CARD_BORDER = new Color(255, 255, 255, 28);
        public static final Color CARD_HEADER_BG = new Color(26, 32, 60, 180);

        // Accents
        public static final Color ACCENT_PURPLE = new Color(168, 85, 247); // Vibrant Violet
        public static final Color ACCENT_INDIGO = new Color(99, 102, 241); // Radiant Indigo
        public static final Color ACCENT_CYAN = new Color(6, 182, 212);    // Neon Cyan
        public static final Color ACCENT_FUCHSIA = new Color(217, 70, 239);// Aurora Fuchsia

        // Feedback Badges
        public static final Color SUCCESS_TEXT = new Color(52, 211, 153);
        public static final Color SUCCESS_BG = new Color(6, 78, 59, 200);
        public static final Color SUCCESS_BORDER = new Color(16, 185, 129);

        public static final Color WARNING_TEXT = new Color(251, 191, 36);
        public static final Color WARNING_BG = new Color(120, 53, 15, 200);
        public static final Color WARNING_BORDER = new Color(245, 158, 11);

        public static final Color INFO_TEXT = new Color(6, 182, 212);
        public static final Color INFO_BG = new Color(8, 47, 73, 200);
        public static final Color INFO_BORDER = new Color(6, 182, 212);

        public static final Color DANGER_TEXT = new Color(248, 113, 113);
        public static final Color DANGER_BG = new Color(127, 29, 29, 200);
        public static final Color DANGER_BORDER = new Color(244, 63, 94);

        // Text
        public static final Color TEXT_WHITE = new Color(255, 255, 255);
        public static final Color TEXT_MUTED = new Color(203, 213, 225);
        public static final Color TEXT_DIM = new Color(100, 116, 139);
    }

    // ==========================================
    // GRADIENT BACKGROUND PANEL WITH PROJECT WATERMARK
    // ==========================================
    public static class GradientBackgroundPanel extends JPanel {
        public GradientBackgroundPanel() {
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

            int w = getWidth();
            int h = getHeight();

            // Multi-stop linear gradient: Obsidian to Deep Nebula to Indigo
            GradientPaint gp1 = new GradientPaint(0, 0, Colors.BG_TOP, 0, h * 0.45f, Colors.BG_MID);
            g2.setPaint(gp1);
            g2.fillRect(0, 0, w, (int)(h * 0.45f));

            GradientPaint gp2 = new GradientPaint(0, h * 0.45f, Colors.BG_MID, 0, h, Colors.BG_BOTTOM);
            g2.setPaint(gp2);
            g2.fillRect(0, (int)(h * 0.45f), w, h);

            // Ambient Radiant Glows (Top Left Violet, Top Right Cyan, Bottom Fuchsia)
            RadialGradientPaint violetGlow = new RadialGradientPaint(
                    w * 0.2f, h * 0.15f, Math.max(w * 0.6f, 350),
                    new float[]{0.0f, 0.6f, 1.0f},
                    new Color[]{new Color(139, 92, 246, 50), new Color(99, 102, 241, 18), new Color(0, 0, 0, 0)}
            );
            g2.setPaint(violetGlow);
            g2.fillRect(0, 0, w, h);

            RadialGradientPaint cyanGlow = new RadialGradientPaint(
                    w * 0.85f, h * 0.25f, Math.max(w * 0.5f, 300),
                    new float[]{0.0f, 0.7f, 1.0f},
                    new Color[]{new Color(6, 182, 212, 40), new Color(6, 182, 212, 12), new Color(0, 0, 0, 0)}
            );
            g2.setPaint(cyanGlow);
            g2.fillRect(0, 0, w, h);

            // PROJECT NAME IN THE BACKGROUND (AESTHETIC WATERMARK)
            Graphics2D wmG = (Graphics2D) g2.create();
            int fontSize = Math.max(48, Math.min(84, w / 9));
            wmG.setFont(new Font("Segoe UI", Font.BOLD, fontSize));
            wmG.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.042f));
            wmG.setColor(Color.WHITE);
            wmG.rotate(Math.toRadians(-8), w / 2.0, h / 2.0);

            String wmText = "NUMBER GUESSING GAME";
            FontMetrics fm = wmG.getFontMetrics();
            int strW = fm.stringWidth(wmText);
            int stepY = fm.getHeight() * 3;
            int stepX = strW + 90;

            for (int y = -h; y < h * 2; y += stepY) {
                for (int x = -w; x < w * 2; x += stepX) {
                    wmG.drawString(wmText, x, y);
                }
            }
            wmG.dispose();

            g2.dispose();
        }
    }

    // ==========================================
    // ROUNDED CARD PANEL
    // ==========================================
    public static class RoundedCardPanel extends JPanel {
        private final int cornerRadius;
        private Color backgroundColor;
        private Color borderColor;

        public RoundedCardPanel(int cornerRadius) {
            this(cornerRadius, Colors.CARD_BG, Colors.CARD_BORDER);
        }

        public RoundedCardPanel(int cornerRadius, Color bg, Color border) {
            this.cornerRadius = cornerRadius;
            this.backgroundColor = bg;
            this.borderColor = border;
            setOpaque(false);
        }

        public void setCustomBackground(Color bg) {
            this.backgroundColor = bg;
            repaint();
        }

        public void setCustomBorder(Color border) {
            this.borderColor = border;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            // Fill rounded card
            g2.setColor(backgroundColor);
            g2.fill(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));

            // Stroke border
            if (borderColor != null) {
                g2.setColor(borderColor);
                g2.setStroke(new BasicStroke(1.2f));
                g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ==========================================
    // MODERN STYLED BUTTON
    // ==========================================
    public static class ModernButton extends JButton {
        public enum ButtonStyle {
            PRIMARY,    // Vibrant Indigo-Purple gradient
            SECONDARY,  // Dark slate outlined
            SUCCESS,    // Emerald Green gradient
            DANGER      // Ruby Red outlined
        }

        private ButtonStyle style;
        private boolean isHovered = false;
        private boolean isPressed = false;
        private int cornerRadius = 12;

        public ModernButton(String text, ButtonStyle style) {
            super(text);
            this.style = style;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setForeground(Colors.TEXT_WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setBorder(new EmptyBorder(10, 20, 10, 20));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    if (isEnabled()) {
                        isHovered = true;
                        repaint();
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (isEnabled()) {
                        isPressed = true;
                        repaint();
                    }
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    isPressed = false;
                    repaint();
                }
            });
        }

        public void setButtonStyle(ButtonStyle style) {
            this.style = style;
            repaint();
        }

        public void setCornerRadius(int radius) {
            this.cornerRadius = radius;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            if (!isEnabled()) {
                g2.setColor(new Color(51, 65, 85, 120));
                g2.fill(new RoundRectangle2D.Float(0, 0, w, h, cornerRadius, cornerRadius));
                g2.setColor(Colors.TEXT_DIM);
            } else {
                switch (style) {
                    case PRIMARY:
                        Color c1 = isPressed ? new Color(79, 70, 229) : (isHovered ? new Color(129, 140, 248) : Colors.ACCENT_INDIGO);
                        Color c2 = isPressed ? new Color(109, 40, 217) : (isHovered ? new Color(167, 139, 250) : Colors.ACCENT_PURPLE);
                        GradientPaint gp = new GradientPaint(0, 0, c1, w, h, c2);
                        g2.setPaint(gp);
                        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, cornerRadius, cornerRadius));

                        // Top border glow
                        g2.setColor(new Color(255, 255, 255, isHovered ? 60 : 35));
                        g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));
                        break;

                    case SUCCESS:
                        Color sc1 = isPressed ? new Color(5, 150, 105) : (isHovered ? new Color(52, 211, 153) : new Color(16, 185, 129));
                        Color sc2 = isPressed ? new Color(4, 120, 87) : (isHovered ? new Color(16, 185, 129) : new Color(5, 150, 105));
                        g2.setPaint(new GradientPaint(0, 0, sc1, w, h, sc2));
                        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, cornerRadius, cornerRadius));
                        g2.setColor(new Color(255, 255, 255, isHovered ? 50 : 25));
                        g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));
                        break;

                    case SECONDARY:
                        Color secBg = isPressed ? new Color(51, 65, 85, 160) : (isHovered ? new Color(51, 65, 85, 220) : new Color(30, 41, 59, 180));
                        g2.setColor(secBg);
                        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, cornerRadius, cornerRadius));
                        g2.setColor(isHovered ? Colors.ACCENT_CYAN : Colors.CARD_BORDER);
                        g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));
                        break;

                    case DANGER:
                        Color dangBg = isPressed ? new Color(153, 27, 27, 200) : (isHovered ? new Color(185, 28, 28, 220) : new Color(127, 29, 29, 140));
                        g2.setColor(dangBg);
                        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, cornerRadius, cornerRadius));
                        g2.setColor(isHovered ? Colors.DANGER_BORDER : new Color(185, 28, 28));
                        g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));
                        break;
                }
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ==========================================
    // MODERN TEXT FIELD WITH PLACEHOLDER
    // ==========================================
    public static class ModernTextField extends JTextField {
        private String placeholder;
        private boolean isFocused = false;

        public ModernTextField(String placeholder) {
            this.placeholder = placeholder;
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.BOLD, 18));
            setForeground(Colors.TEXT_WHITE);
            setCaretColor(Colors.ACCENT_CYAN);
            setHorizontalAlignment(JTextField.CENTER);
            setBorder(new EmptyBorder(12, 16, 12, 16));

            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    isFocused = true;
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    isFocused = false;
                    repaint();
                }
            });
        }

        public void setPlaceholder(String placeholder) {
            this.placeholder = placeholder;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            // Background fill
            g2.setColor(new Color(15, 23, 42, 230));
            g2.fill(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, 12, 12));

            // Border (glows cyan when focused)
            if (isFocused) {
                g2.setColor(Colors.ACCENT_CYAN);
                g2.setStroke(new BasicStroke(1.8f));
            } else {
                g2.setColor(Colors.CARD_BORDER);
                g2.setStroke(new BasicStroke(1.0f));
            }
            g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, 12, 12));

            // Placeholder text when empty and not focused
            if ((getText() == null || getText().isEmpty()) && placeholder != null) {
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
                g2.setColor(Colors.TEXT_DIM);
                FontMetrics fm = g2.getFontMetrics();
                int textX = (w - fm.stringWidth(placeholder)) / 2;
                int textY = (h - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(placeholder, textX, textY);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ==========================================
    // MODERN ATTEMPTS PROGRESS BAR
    // ==========================================
    public static class AttemptsProgressBar extends JComponent {
        private int currentRemaining = 7;
        private int maxAttempts = 7;

        public AttemptsProgressBar() {
            setPreferredSize(new Dimension(280, 14));
            setMinimumSize(new Dimension(200, 14));
        }

        public void setAttempts(int remaining, int max) {
            this.currentRemaining = Math.max(0, Math.min(remaining, max));
            this.maxAttempts = Math.max(1, max);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            int radius = h;

            // Track background
            g2.setColor(new Color(15, 23, 42, 200));
            g2.fill(new RoundRectangle2D.Float(0, 0, w, h, radius, radius));
            g2.setColor(new Color(51, 65, 85, 120));
            g2.draw(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, radius, radius));

            // Calculate fill width
            float ratio = (float) currentRemaining / (float) maxAttempts;
            int fillW = Math.max(0, (int) (w * ratio));

            if (fillW > 0) {
                // Color transition: emerald (>50%) -> amber (25-50%) -> crimson (<=25%)
                Color barColor1;
                Color barColor2;
                if (ratio > 0.5f) {
                    barColor1 = new Color(16, 185, 129);
                    barColor2 = new Color(52, 211, 153);
                } else if (ratio > 0.25f) {
                    barColor1 = new Color(245, 158, 11);
                    barColor2 = new Color(251, 191, 36);
                } else {
                    barColor1 = new Color(239, 68, 68);
                    barColor2 = new Color(248, 113, 113);
                }

                g2.setPaint(new GradientPaint(0, 0, barColor1, fillW, 0, barColor2));
                g2.fill(new RoundRectangle2D.Float(0, 0, fillW, h, radius, radius));
            }

            g2.dispose();
        }
    }

    // ==========================================
    // CONFETTI CELEBRATION OVERLAY
    // ==========================================
    public static class ConfettiOverlay extends JComponent {
        private static final class Particle {
            float x, y;
            float vx, vy;
            float size;
            float angle;
            float angularSpeed;
            Color color;
            boolean isCircle;

            Particle(float x, float y, Random rng) {
                this.x = x;
                this.y = y;
                this.vx = (rng.nextFloat() - 0.5f) * 6.0f;
                this.vy = -(rng.nextFloat() * 4.0f + 2.0f); // initial pop upwards
                this.size = rng.nextFloat() * 8.0f + 6.0f;
                this.angle = rng.nextFloat() * 360.0f;
                this.angularSpeed = (rng.nextFloat() - 0.5f) * 12.0f;
                this.isCircle = rng.nextBoolean();

                Color[] palette = {
                    new Color(245, 158, 11),  // Gold
                    new Color(56, 189, 248),  // Cyan
                    new Color(236, 72, 153),  // Pink
                    new Color(16, 185, 129),  // Emerald
                    new Color(139, 92, 246),  // Violet
                    new Color(251, 191, 36),  // Amber
                    new Color(255, 255, 255)  // White star
                };
                this.color = palette[rng.nextInt(palette.length)];
            }

            void update() {
                x += vx;
                y += vy;
                vy += 0.16f; // gravity
                vx *= 0.985f; // air drag
                angle += angularSpeed;
            }
        }

        private final List<Particle> particles = new ArrayList<>();
        private final Timer timer;
        private final Random rng = new Random();
        private boolean active = false;

        public ConfettiOverlay() {
            setOpaque(false);
            setVisible(false);

            timer = new Timer(16, e -> {
                if (!active || particles.isEmpty()) {
                    stopCelebration();
                    return;
                }

                int h = getHeight();
                particles.removeIf(p -> p.y > h + 50);

                for (Particle p : particles) {
                    p.update();
                }

                if (particles.isEmpty()) {
                    stopCelebration();
                } else {
                    repaint();
                }
            });
        }

        public void startCelebration() {
            particles.clear();
            int w = Math.max(getWidth(), 800);
            int h = Math.max(getHeight(), 700);

            // Spawn 100 particles across top third of window
            for (int i = 0; i < 110; i++) {
                float startX = rng.nextFloat() * w;
                float startY = rng.nextFloat() * (h * 0.4f);
                particles.add(new Particle(startX, startY, rng));
            }

            active = true;
            setVisible(true);
            timer.start();
            repaint();
        }

        public void stopCelebration() {
            active = false;
            particles.clear();
            timer.stop();
            setVisible(false);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (!active || particles.isEmpty()) return;

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            for (Particle p : particles) {
                Graphics2D pG = (Graphics2D) g2.create();
                pG.translate(p.x, p.y);
                pG.rotate(Math.toRadians(p.angle));
                pG.setColor(p.color);

                if (p.isCircle) {
                    pG.fillOval((int)(-p.size / 2), (int)(-p.size / 2), (int)p.size, (int)p.size);
                } else {
                    pG.fillRect((int)(-p.size / 2), (int)(-p.size / 4), (int)p.size, (int)(p.size / 2));
                }
                pG.dispose();
            }

            g2.dispose();
        }
    }
}
