import java.io.File;
import java.util.List;

/**
 * Automated Test Suite for Number Guessing Game Logic, Session Stats, and Real-World Features.
 * Verifies all 5 core requirements of Infobyte Internship Task 1:
 * - 1. Game Setup & Range Verification
 * - 2. User Input Validation & Feedback
 * - 3. Limited Attempts Tracking & Loss Condition
 * - 4. Win Condition, Score Calculation & Best Score
 * - 5. Replay Option & State Reset
 * Plus Real-World Features:
 * - 6. Binary Search Space Narrowing & Optimal Guess Advisor
 * - 7. Educational Hint / Clue Generator
 * - 8. CSV Leaderboard Persistence & Report Generation
 */
public class GameLogicTest {

    private static int testsPassed = 0;
    private static int testsTotal = 0;

    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println(" RUNNING AUTOMATED TESTS: NUMBER GUESSING GAME");
        System.out.println("==================================================");

        testSecretNumberGeneration();
        testInputValidation();
        testAttemptTrackingAndFeedback();
        testLossCondition();
        testScoringAndBestScore();
        testDifficultyLevels();
        testReplayReset();
        testRealWorldFeatures();
        testDuelAndPlayerManager();

        System.out.println("==================================================");
        System.out.printf("TEST RESULTS: %d / %d PASSED\n", testsPassed, testsTotal);
        if (testsPassed == testsTotal) {
            System.out.println(">>> ALL TESTS PASSED SUCCESSFULLY! <<<");
        } else {
            System.err.println(">>> SOME TESTS FAILED! <<<");
            System.exit(1);
        }
        System.out.println("==================================================");
    }

    private static void assertTrue(String testName, boolean condition) {
        testsTotal++;
        if (condition) {
            testsPassed++;
            System.out.println("[PASS] " + testName);
        } else {
            System.err.println("[FAIL] " + testName);
        }
    }

    private static void testSecretNumberGeneration() {
        System.out.println("\n--- 1. Game Setup & Random Range Tests ---");
        for (int i = 0; i < 50; i++) {
            GameLogic logic = new GameLogic(Difficulty.MEDIUM);
            assertTrue("Secret number is hidden during active game", logic.getSecretNumberIfEnded() == -1);
            
            for (int g = 1; g <= 7; g++) {
                GuessResult res = logic.submitGuess(String.valueOf(g));
                if (res.isRoundOver()) break;
            }
            int revealed = logic.getSecretNumberIfEnded();
            assertTrue("Secret number is within 1..100 range: " + revealed, revealed >= 1 && revealed <= 100);
        }
    }

    private static void testInputValidation() {
        System.out.println("\n--- 2. Input Validation Tests ---");
        GameLogic logic = new GameLogic(Difficulty.MEDIUM);

        GuessResult res1 = logic.submitGuess("");
        assertTrue("Rejects empty string without crashing", res1.isInputError());
        assertTrue("Empty string does not consume attempt", logic.getAttemptsUsed() == 0);

        GuessResult res2 = logic.submitGuess("   ");
        assertTrue("Rejects whitespace string", res2.isInputError());
        assertTrue("Whitespace does not consume attempt", logic.getAttemptsUsed() == 0);

        GuessResult res3 = logic.submitGuess("abc");
        assertTrue("Rejects alphabetic input", res3.isInputError());
        assertTrue("Alphabetic input does not consume attempt", logic.getAttemptsUsed() == 0);

        GuessResult res4 = logic.submitGuess("45.67");
        assertTrue("Rejects decimal numbers", res4.isInputError());
        assertTrue("Decimal input does not consume attempt", logic.getAttemptsUsed() == 0);

        GuessResult res5 = logic.submitGuess("0");
        assertTrue("Rejects guess below min range", res5.getStatus() == GuessResult.Status.OUT_OF_RANGE);
        assertTrue("Below-range input does not consume attempt", logic.getAttemptsUsed() == 0);

        GuessResult res6 = logic.submitGuess("101");
        assertTrue("Rejects guess above max range", res6.getStatus() == GuessResult.Status.OUT_OF_RANGE);
        assertTrue("Above-range input does not consume attempt", logic.getAttemptsUsed() == 0);
    }

    private static void testAttemptTrackingAndFeedback() {
        System.out.println("\n--- 3. Attempt Tracking & Feedback Tests ---");
        GameLogic logic = new GameLogic(Difficulty.MEDIUM);
        assertTrue("Initial attempts remaining is 7", logic.getRemainingAttempts() == 7);

        GuessResult r1 = logic.submitGuess("50");
        assertTrue("First valid guess consumes exactly 1 attempt", logic.getAttemptsUsed() == 1);
        assertTrue("Attempts remaining is 6", logic.getRemainingAttempts() == 6);
        assertTrue("Feedback matches Too High or Too Low or Correct", 
                r1.getStatus() == GuessResult.Status.TOO_HIGH ||
                r1.getStatus() == GuessResult.Status.TOO_LOW ||
                r1.getStatus() == GuessResult.Status.CORRECT);

        GuessResult rDup = logic.submitGuess("50");
        assertTrue("Duplicate guess detected", rDup.getStatus() == GuessResult.Status.ALREADY_GUESSED);
        assertTrue("Duplicate guess does not consume extra attempt", logic.getAttemptsUsed() == 1);
    }

    private static void testLossCondition() {
        System.out.println("\n--- 4. Limited Attempts & Loss Condition Tests ---");
        GameLogic logic = new GameLogic(Difficulty.MEDIUM);

        int guess = 1;
        while (!logic.isGameOver()) {
            logic.submitGuess(String.valueOf(guess++));
        }

        assertTrue("Game ends after exhaustion or correct guess", logic.isGameOver());
        assertTrue("Secret number is revealed when round ends", logic.getSecretNumberIfEnded() >= 1 && logic.getSecretNumberIfEnded() <= 100);
        if (!logic.isGameWon()) {
            assertTrue("Loss awards 0 points", logic.getCurrentRoundScore() == 0);
            assertTrue("Remaining attempts is 0 on loss", logic.getRemainingAttempts() == 0);
        }
    }

    private static void testScoringAndBestScore() {
        System.out.println("\n--- 5. Scoring & Session Statistics Tests ---");
        GameStats stats = new GameStats();
        assertTrue("Initial games played is 0", stats.getTotalGamesPlayed() == 0);
        assertTrue("Initial best score is 0", stats.getBestScore() == 0);

        stats.recordRound(true, 500);
        assertTrue("Games played is 1", stats.getTotalGamesPlayed() == 1);
        assertTrue("Total wins is 1", stats.getTotalWins() == 1);
        assertTrue("Best score updated to 500", stats.getBestScore() == 500);
        assertTrue("Win rate is 100.0%", stats.getWinPercentage() == 100.0);

        stats.recordRound(false, 0);
        assertTrue("Games played is 2", stats.getTotalGamesPlayed() == 2);
        assertTrue("Total losses is 1", stats.getTotalLosses() == 1);
        assertTrue("Best score remains 500", stats.getBestScore() == 500);
        assertTrue("Win rate is 50.0%", stats.getWinPercentage() == 50.0);

        stats.recordRound(true, 850);
        assertTrue("Best score updated to 850", stats.getBestScore() == 850);
        assertTrue("Win rate is ~66.7%", Math.abs(stats.getWinPercentage() - 66.666) < 0.1);
    }

    private static void testDifficultyLevels() {
        System.out.println("\n--- 6. Difficulty Configuration Tests ---");
        GameLogic easy = new GameLogic(Difficulty.EASY);
        assertTrue("Easy min range is 1", easy.getDifficulty().getMinRange() == 1);
        assertTrue("Easy max range is 50", easy.getDifficulty().getMaxRange() == 50);
        assertTrue("Easy max attempts is 10", easy.getMaxAttempts() == 10);

        GameLogic med = new GameLogic(Difficulty.MEDIUM);
        assertTrue("Medium min range is 1", med.getDifficulty().getMinRange() == 1);
        assertTrue("Medium max range is 100", med.getDifficulty().getMaxRange() == 100);
        assertTrue("Medium max attempts is 7", med.getMaxAttempts() == 7);

        GameLogic hard = new GameLogic(Difficulty.HARD);
        assertTrue("Hard min range is 1", hard.getDifficulty().getMinRange() == 1);
        assertTrue("Hard max range is 200", hard.getDifficulty().getMaxRange() == 200);
        assertTrue("Hard max attempts is 6", hard.getMaxAttempts() == 6);
    }

    private static void testReplayReset() {
        System.out.println("\n--- 7. Replay & State Reset Tests ---");
        GameLogic logic = new GameLogic(Difficulty.MEDIUM);
        logic.submitGuess("10");
        logic.submitGuess("20");
        assertTrue("Attempts used is 2 before reset", logic.getAttemptsUsed() == 2);
        assertTrue("History has 2 items", logic.getGuessesHistory().size() == 2);

        logic.startNewGame(Difficulty.MEDIUM);
        assertTrue("Attempts used reset to 0", logic.getAttemptsUsed() == 0);
        assertTrue("Remaining attempts reset to 7", logic.getRemainingAttempts() == 7);
        assertTrue("History is cleared", logic.getGuessesHistory().isEmpty());
        assertTrue("Game is not over", !logic.isGameOver());
        assertTrue("Secret number is hidden again", logic.getSecretNumberIfEnded() == -1);
    }

    private static void testRealWorldFeatures() {
        System.out.println("\n--- 8. Real-World Educational & Persistence Tests ---");
        GameLogic logic = new GameLogic(Difficulty.MEDIUM);

        // Search space initially 100
        assertTrue("Initial search space is 100", logic.getRemainingSearchSpace() == 100);
        assertTrue("Initial optimal guess is 50", logic.getOptimalBinarySearchGuess() == 50);

        // Hint generation
        String hint1 = logic.getNextHint();
        assertTrue("Hint 1 contains parity clue", hint1.contains("EVEN") || hint1.contains("ODD"));
        assertTrue("Hints used is 1", logic.getHintsUsed() == 1);

        String hint2 = logic.getNextHint();
        assertTrue("Hint 2 contains divisibility clue", hint2.contains("divisible") || hint2.contains("multiple"));

        // Test CSV Persistence
        GameRecord rec = new GameRecord("Test Intern", "Medium", 850, 3, 7, true);
        ScorePersistence.saveRecord(rec);
        List<GameRecord> loaded = ScorePersistence.loadRecords();
        assertTrue("Loaded records is non-empty", !loaded.isEmpty());
        assertTrue("Top record has valid score", loaded.get(0).getScore() >= 0);

        // Test Report Generation
        GameStats stats = new GameStats();
        stats.recordRound(true, 850);
        File report = ScorePersistence.exportPerformanceReport("Test Intern", stats, List.of(rec));
        assertTrue("Report file exists on disk", report.exists() && report.length() > 0);
    }

    private static void testDuelAndPlayerManager() {
        System.out.println("\n--- 9. 2-Player Head-to-Head Duel & Player Manager Tests ---");
        
        // PlayerManager tests
        PlayerManager pm = new PlayerManager();
        pm.addPlayer("Spandana");
        pm.addPlayer("Alex");
        assertTrue("PlayerManager contains Spandana", pm.getPlayers().contains("Spandana"));
        assertTrue("PlayerManager contains Alex", pm.getPlayers().contains("Alex"));
        pm.setActivePlayer("Alex");
        assertTrue("Active player switched to Alex", "Alex".equals(pm.getActivePlayer()));

        // VersusDuelLogic tests
        VersusDuelLogic duel = new VersusDuelLogic("Spandana", "Alex", Difficulty.EASY);
        assertTrue("Duel starts with Player 1", duel.getCurrentTurn() == 1);
        assertTrue("Active player is Spandana", "Spandana".equals(duel.getCurrentActivePlayerName()));
        assertTrue("Player 1 attempts initially 0", duel.getPlayer1Attempts() == 0);
        assertTrue("Player 2 attempts initially 0", duel.getPlayer2Attempts() == 0);
        assertTrue("Duel is not over initially", !duel.isDuelOver());

        // Player 1 invalid guess
        VersusDuelLogic.DuelGuessResult resInv = duel.submitDuelGuess("abc");
        assertTrue("Invalid input rejected", resInv.getOutcome() == VersusDuelLogic.DuelGuessResult.Outcome.INVALID_INPUT);
        assertTrue("Turn did not switch on invalid input", duel.getCurrentTurn() == 1);

        // Player 1 makes a valid guess that is either too high or too low (unless lucky bullseye)
        VersusDuelLogic.DuelGuessResult res1 = duel.submitDuelGuess("1");
        if (!res1.isDuelEnded()) {
            assertTrue("Turn switched to Player 2", duel.getCurrentTurn() == 2);
            assertTrue("Active player is Alex", "Alex".equals(duel.getCurrentActivePlayerName()));
            assertTrue("Player 1 has 1 attempt", duel.getPlayer1Attempts() == 1);
            assertTrue("Player 2 has 0 attempts", duel.getPlayer2Attempts() == 0);
        }

        // Test saving and loading duel records
        ScorePersistence.saveDuelRecord("Spandana", "Alex", "Spandana", 3, 14.5, "Medium");
        List<String[]> duels = ScorePersistence.loadDuelRecords();
        assertTrue("Duel records loaded successfully", !duels.isEmpty());
        assertTrue("Latest duel contains Spandana", duels.get(duels.size() - 1)[0].contains("Spandana") || duels.get(duels.size() - 1)[1].contains("Spandana"));
    }
}

