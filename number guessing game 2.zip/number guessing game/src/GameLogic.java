import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Core game logic for the Number Guessing Game.
 * Handles secret number generation, guess validation, attempt tracking,
 * score calculation, and state management.
 * 
 * Enhanced with Real-World Educational & Gameplay Features:
 * - Binary search space tracking [currentLowBound, currentHighBound]
 * - Optimal O(log N) guess advisor
 * - Educational mathematical clue generator (parity, divisibility, digit sum, prime)
 * - Deduction efficiency calculation
 * 
 * Satisfies all Infobyte Internship Task 1 requirements.
 */
public class GameLogic {

    private Difficulty difficulty;
    private int secretNumber;
    private int attemptsUsed;
    private boolean gameOver;
    private boolean gameWon;
    private int currentRoundScore;
    private int hintsUsed;
    private int currentLowBound;
    private int currentHighBound;
    private final List<Integer> guessesHistory;

    /**
     * Initializes a new game session with default Medium difficulty (1–100, 7 attempts).
     */
    public GameLogic() {
        this(Difficulty.MEDIUM);
    }

    /**
     * Initializes a new game with the specified difficulty.
     * 
     * @param difficulty Selected difficulty level
     */
    public GameLogic(Difficulty difficulty) {
        this.guessesHistory = new ArrayList<>();
        startNewGame(difficulty);
    }

    /**
     * Starts a new round: resets attempts, clears history, and generates
     * a fresh random secret number within the difficulty range.
     * 
     * @param difficulty Difficulty to use for the new round
     */
    public void startNewGame(Difficulty difficulty) {
        if (difficulty == null) {
            difficulty = Difficulty.MEDIUM;
        }
        this.difficulty = difficulty;
        this.attemptsUsed = 0;
        this.gameOver = false;
        this.gameWon = false;
        this.currentRoundScore = 0;
        this.hintsUsed = 0;
        this.currentLowBound = difficulty.getMinRange();
        this.currentHighBound = difficulty.getMaxRange();
        this.guessesHistory.clear();

        // Generate random number between minRange and maxRange (inclusive)
        this.secretNumber = ThreadLocalRandom.current().nextInt(
                difficulty.getMinRange(),
                difficulty.getMaxRange() + 1
        );
    }

    /**
     * Validates and evaluates a player's raw string guess.
     * Safely handles empty input, non-numeric values, and out-of-range numbers
     * without throwing unhandled exceptions.
     * 
     * @param rawInput String input from user
     * @return GuessResult detailing the outcome
     */
    public GuessResult submitGuess(String rawInput) {
        if (gameOver) {
            return new GuessResult(
                    GuessResult.Status.GAME_OVER_LOST,
                    "This round is over. Click 'Play Again' to start a new game!",
                    0, attemptsUsed, getRemainingAttempts(), currentRoundScore,
                    true, gameWon, secretNumber
            );
        }

        // 1. Validate empty / whitespace input
        if (rawInput == null || rawInput.trim().isEmpty()) {
            return new GuessResult(
                    GuessResult.Status.INVALID_EMPTY,
                    "Please enter a number before submitting.",
                    0, attemptsUsed, getRemainingAttempts(), 0,
                    false, false, -1
            );
        }

        // 2. Validate numeric format
        int guess;
        try {
            guess = Integer.parseInt(rawInput.trim());
        } catch (NumberFormatException e) {
            return new GuessResult(
                    GuessResult.Status.INVALID_NON_NUMERIC,
                    "Invalid input! Please enter a valid whole number.",
                    0, attemptsUsed, getRemainingAttempts(), 0,
                    false, false, -1
            );
        }

        // 3. Validate range bounds
        if (guess < difficulty.getMinRange() || guess > difficulty.getMaxRange()) {
            return new GuessResult(
                    GuessResult.Status.OUT_OF_RANGE,
                    String.format("Out of range! Please guess between %d and %d.", 
                            difficulty.getMinRange(), difficulty.getMaxRange()),
                    guess, attemptsUsed, getRemainingAttempts(), 0,
                    false, false, -1
            );
        }

        // 4. Check for duplicate guesses in the same round (friendly reminder, does not consume attempt)
        if (guessesHistory.contains(guess)) {
            return new GuessResult(
                    GuessResult.Status.ALREADY_GUESSED,
                    String.format("You already guessed %d! Try a different number.", guess),
                    guess, attemptsUsed, getRemainingAttempts(), 0,
                    false, false, -1
            );
        }

        // 5. Valid guess — consume one attempt and record history
        attemptsUsed++;
        guessesHistory.add(guess);
        int remaining = getRemainingAttempts();

        // 6. Evaluate guess against secret number
        if (guess == secretNumber) {
            gameOver = true;
            gameWon = true;
            currentLowBound = secretNumber;
            currentHighBound = secretNumber;
            currentRoundScore = calculateScore(attemptsUsed, difficulty, hintsUsed);
            String winMsg = String.format("🎉 Bullseye! %d is correct! You won in %d %s! (+%d pts)",
                    secretNumber, attemptsUsed, (attemptsUsed == 1 ? "attempt" : "attempts"), currentRoundScore);
            return new GuessResult(
                    GuessResult.Status.CORRECT,
                    winMsg,
                    guess, attemptsUsed, remaining, currentRoundScore,
                    true, true, secretNumber
            );
        } else if (remaining <= 0) {
            // Out of attempts — game over loss
            gameOver = true;
            gameWon = false;
            currentRoundScore = 0;
            String lossMsg = String.format("💀 Game Over! You ran out of attempts. The secret number was %d.", secretNumber);
            return new GuessResult(
                    GuessResult.Status.GAME_OVER_LOST,
                    lossMsg,
                    guess, attemptsUsed, 0, 0,
                    true, false, secretNumber
            );
        } else if (guess > secretNumber) {
            // Secret is smaller than guess
            currentHighBound = Math.min(currentHighBound, guess - 1);
            return new GuessResult(
                    GuessResult.Status.TOO_HIGH,
                    "Too high! Try a smaller number.",
                    guess, attemptsUsed, remaining, 0,
                    false, false, -1
            );
        } else {
            // Secret is larger than guess
            currentLowBound = Math.max(currentLowBound, guess + 1);
            return new GuessResult(
                    GuessResult.Status.TOO_LOW,
                    "Too low! Try a larger number.",
                    guess, attemptsUsed, remaining, 0,
                    false, false, -1
            );
        }
    }

    /**
     * Calculates score based on remaining attempts, difficulty multiplier, and hint penalty.
     */
    public static int calculateScore(int attemptsUsed, Difficulty diff, int hintsUsed) {
        int remainingPlusOne = diff.getMaxAttempts() - attemptsUsed + 1;
        if (remainingPlusOne <= 0) remainingPlusOne = 1;
        double rawScore = remainingPlusOne * 100.0 * diff.getScoreMultiplier();
        if (attemptsUsed == 1) {
            rawScore += 500 * diff.getScoreMultiplier(); // Bullseye bonus
        }
        int penalty = hintsUsed * 50;
        return Math.max(0, (int) Math.round(rawScore) - penalty);
    }

    public static int calculateScore(int attemptsUsed, Difficulty diff) {
        return calculateScore(attemptsUsed, diff, 0);
    }

    /**
     * Generates an educational mathematical clue based on the secret number.
     */
    public String getNextHint() {
        if (gameOver) {
            return "Round is already over! Secret number was: " + secretNumber;
        }

        hintsUsed++;
        switch (hintsUsed) {
            case 1:
                return "💡 Clue #1: The secret number is " + (secretNumber % 2 == 0 ? "EVEN" : "ODD") + ".";
            case 2:
                if (secretNumber % 3 == 0) return "💡 Clue #2: The number is divisible by 3.";
                if (secretNumber % 5 == 0) return "💡 Clue #2: The number is a multiple of 5.";
                if (secretNumber % 7 == 0) return "💡 Clue #2: The number is divisible by 7.";
                return "💡 Clue #2: The number is NOT divisible by 2, 3, or 5.";
            case 3:
                int sum = 0, temp = secretNumber;
                while (temp > 0) {
                    sum += temp % 10;
                    temp /= 10;
                }
                return "💡 Clue #3: The sum of its digits is " + sum + ".";
            case 4:
                return "💡 Clue #4: The number is " + (isPrime(secretNumber) ? "a PRIME number." : "a COMPOSITE number.");
            default:
                return "💡 Clue: Narrowed range is [" + currentLowBound + " to " + currentHighBound + "]. Recommended guess: " + getOptimalBinarySearchGuess() + "!";
        }
    }

    private static boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) return false;
        }
        return true;
    }

    /**
     * Evaluates proximity temperature radar without revealing the secret number.
     */
    public String getProximityIndicator(int guess) {
        int diff = Math.abs(guess - secretNumber);
        if (diff == 0) return "🎯 Bullseye!";
        if (diff <= 3) return "🔥 Boiling Hot! (Within 3 numbers)";
        if (diff <= 8) return "♨️ Very Warm! (Within 8 numbers)";
        if (diff <= 15) return "🌤️ Lukewarm (Within 15 numbers)";
        if (diff <= 25) return "❄️ Cold (Over 15 numbers away)";
        return "🧊 Freezing (Over 25 numbers away)";
    }

    public int getCurrentLowBound() {
        return currentLowBound;
    }

    public int getCurrentHighBound() {
        return currentHighBound;
    }

    public int getRemainingSearchSpace() {
        return Math.max(1, currentHighBound - currentLowBound + 1);
    }

    public int getOptimalBinarySearchGuess() {
        return (currentLowBound + currentHighBound) / 2;
    }

    public int getHintsUsed() {
        return hintsUsed;
    }

    public int getRemainingAttempts() {
        return Math.max(0, difficulty.getMaxAttempts() - attemptsUsed);
    }

    public int getMaxAttempts() {
        return difficulty.getMaxAttempts();
    }

    public int getAttemptsUsed() {
        return attemptsUsed;
    }

    public Difficulty getDifficulty() {
        return difficulty;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public boolean isGameWon() {
        return gameWon;
    }

    public int getCurrentRoundScore() {
        return currentRoundScore;
    }

    public List<Integer> getGuessesHistory() {
        return Collections.unmodifiableList(guessesHistory);
    }

    public int getSecretNumberIfEnded() {
        return gameOver ? secretNumber : -1;
    }
}
