import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * Main GUI application window for the Number Guessing Game.
 * Features modern dark-navy gradient styling, responsive layout,
 * interactive attempts progress indicator, dynamic feedback badges,
 * session performance statistics, and confetti victory celebration.
 * 
 * Real-World Additions:
 * - 2-Player Competitive Head-to-Head Duel Mode (Speed & deduction race)
 * - Multi-Player Profile Management (Add & switch players)
 * - Binary search advisor & candidate space narrowing tracker
 * - Educational mathematical clue generator (Parity, Divisibility, Digit sum, Prime)
 * - Persistent local CSV leaderboards (Solo & 2-Player Duels)
 * - Formal Internship Performance Report exporter (.txt)
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public class NumberGuessingGame extends JFrame {

    public enum GameMode {
        SOLO,
        VERSUS_DUEL
    }

    // Core Logic, Stats & Players
    private final GameLogic gameLogic;
    private final GameStats gameStats;
    private final PlayerManager playerManager;
    private VersusDuelLogic duelLogic;
    private final List<GameRecord> sessionRecords;

    private GameMode currentMode = GameMode.SOLO;
    private String player1Name = "Spandana";
    private String player2Name = "Player 2";
    private int winStreak = 0;

    // Mode Selector Controls
    private final UIComponents.ModernButton soloModeBtn;
    private final UIComponents.ModernButton versusModeBtn;

    // UI Widgets
    private final UIComponents.ConfettiOverlay confettiOverlay;
    private final UIComponents.ModernTextField guessInput;
    private final UIComponents.ModernButton submitButton;
    private final UIComponents.ModernButton hintButton;
    private final UIComponents.AttemptsProgressBar attemptsProgressBar;
    private final JLabel attemptsLabel;
    private final JLabel rangeCardLabel;
    private final JLabel advisorLabel;
    private final JLabel proximityLabel;
    private final JLabel rankStreakLabel;
    private final JPanel feedbackPanel;
    private final JLabel feedbackIconLabel;
    private final JLabel feedbackTextLabel;
    private final JLabel guessesHistoryLabel;
    private final JLabel playerBadgeLabel;
    private final JLabel duelTurnBadgeLabel;

    // Stats Labels
    private final JLabel currentScoreValueLabel;
    private final JLabel bestScoreValueLabel;
    private final JLabel winRateValueLabel;
    private final JLabel gamesPlayedValueLabel;

    // Difficulty Buttons
    private final UIComponents.ModernButton easyBtn;
    private final UIComponents.ModernButton medBtn;
    private final UIComponents.ModernButton hardBtn;

    // Bottom Action Buttons
    private final UIComponents.ModernButton playAgainBtn;
    private final UIComponents.ModernButton leaderboardBtn;
    private final UIComponents.ModernButton exportReportBtn;
    private final UIComponents.ModernButton exitBtn;

    public NumberGuessingGame() {
        this.gameLogic = new GameLogic(Difficulty.MEDIUM);
        this.gameStats = new GameStats();
        this.playerManager = new PlayerManager();
        this.sessionRecords = new ArrayList<>();

        if (!playerManager.getPlayers().isEmpty()) {
            this.player1Name = playerManager.getActivePlayer();
            List<String> all = playerManager.getPlayers();
            this.player2Name = all.size() > 1 ? all.get(1) : "Player 2";
        }
        this.duelLogic = new VersusDuelLogic(player1Name, player2Name, Difficulty.MEDIUM);

        setTitle("Number Guessing Game | Infobyte Internship Task 1");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(840, 960);
        setMinimumSize(new Dimension(760, 840));
        setLocationRelativeTo(null);

        // Initialize Confetti Overlay on GlassPane
        this.confettiOverlay = new UIComponents.ConfettiOverlay();
        setGlassPane(confettiOverlay);

        // Mode switch buttons
        this.soloModeBtn = new UIComponents.ModernButton("🎯 Solo Mode", UIComponents.ModernButton.ButtonStyle.PRIMARY);
        this.versusModeBtn = new UIComponents.ModernButton("⚔️ 2-Player Duel", UIComponents.ModernButton.ButtonStyle.SECONDARY);

        // UI Controls
        this.guessInput = new UIComponents.ModernTextField("Enter your guess...");
        this.submitButton = new UIComponents.ModernButton("SUBMIT GUESS", UIComponents.ModernButton.ButtonStyle.PRIMARY);
        this.hintButton = new UIComponents.ModernButton("💡 Clue", UIComponents.ModernButton.ButtonStyle.SECONDARY);
        this.attemptsProgressBar = new UIComponents.AttemptsProgressBar();
        this.attemptsLabel = new JLabel();
        this.rangeCardLabel = new JLabel();
        this.advisorLabel = new JLabel();
        this.proximityLabel = new JLabel("🧭 Radar: Awaiting guess...", SwingConstants.RIGHT);
        this.rankStreakLabel = new JLabel("🎖️ Rank: Novice Guesser  |  🔥 Streak: 0");
        this.feedbackPanel = new JPanel();
        this.feedbackIconLabel = new JLabel();
        this.feedbackTextLabel = new JLabel();
        this.guessesHistoryLabel = new JLabel();
        this.playerBadgeLabel = new JLabel();
        this.duelTurnBadgeLabel = new JLabel("👉 Player 1's Turn", SwingConstants.CENTER);

        this.currentScoreValueLabel = new JLabel("0 pts", SwingConstants.CENTER);
        this.bestScoreValueLabel = new JLabel("0 pts", SwingConstants.CENTER);
        this.winRateValueLabel = new JLabel("0.0%", SwingConstants.CENTER);
        this.gamesPlayedValueLabel = new JLabel("0 (0W / 0L)", SwingConstants.CENTER);

        this.easyBtn = new UIComponents.ModernButton("Easy (1-50)", UIComponents.ModernButton.ButtonStyle.SECONDARY);
        this.medBtn = new UIComponents.ModernButton("Medium (1-100)", UIComponents.ModernButton.ButtonStyle.PRIMARY);
        this.hardBtn = new UIComponents.ModernButton("Hard (1-200)", UIComponents.ModernButton.ButtonStyle.SECONDARY);

        this.playAgainBtn = new UIComponents.ModernButton("🔄 Play Again", UIComponents.ModernButton.ButtonStyle.SUCCESS);
        this.leaderboardBtn = new UIComponents.ModernButton("🏆 Leaderboard", UIComponents.ModernButton.ButtonStyle.SECONDARY);
        this.exportReportBtn = new UIComponents.ModernButton("📄 Export Report", UIComponents.ModernButton.ButtonStyle.SECONDARY);
        this.exitBtn = new UIComponents.ModernButton("Exit", UIComponents.ModernButton.ButtonStyle.SECONDARY);

        // Root container with dark navy / purple gradient
        UIComponents.GradientBackgroundPanel rootPanel = new UIComponents.GradientBackgroundPanel();
        rootPanel.setLayout(new BorderLayout());

        // Scrollable content area so layout never clips on smaller screens
        JPanel contentContainer = new JPanel();
        contentContainer.setOpaque(false);
        contentContainer.setLayout(new BoxLayout(contentContainer, BoxLayout.Y_AXIS));
        contentContainer.setBorder(new EmptyBorder(16, 28, 20, 28));

        // 1. Header Section
        contentContainer.add(createHeaderSection());
        contentContainer.add(Box.createVerticalStrut(12));

        // 2. Mode Selector Section
        contentContainer.add(createModeSelectorSection());
        contentContainer.add(Box.createVerticalStrut(12));

        // 3. Difficulty Selector
        contentContainer.add(createDifficultySection());
        contentContainer.add(Box.createVerticalStrut(12));

        // 4. Main Gameplay Card
        contentContainer.add(createGameCard());
        contentContainer.add(Box.createVerticalStrut(12));

        // 5. Session Statistics Card
        contentContainer.add(createStatsCard());
        contentContainer.add(Box.createVerticalStrut(14));

        // 6. Bottom Action Controls
        contentContainer.add(createBottomControls());

        JScrollPane scrollPane = new JScrollPane(contentContainer);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        rootPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(rootPanel);

        // Bind interactive events
        setupEventHandlers();

        // Initial UI sync
        syncGameUI();

        // Focus guess input initially
        SwingUtilities.invokeLater(() -> guessInput.requestFocusInWindow());
    }

    // ==========================================
    // UI BUILDER METHODS
    // ==========================================

    private JPanel createHeaderSection() {
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Top Row with Internship Badge, Player Switcher & Add Player
        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        topRow.setOpaque(false);

        JPanel badgePanel = new UIComponents.RoundedCardPanel(12, new Color(99, 102, 241, 35), new Color(129, 140, 248, 120));
        badgePanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 3));
        JLabel badgeLabel = new JLabel("INFOBYTE INTERNSHIP * TASK 1");
        badgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badgeLabel.setForeground(UIComponents.Colors.ACCENT_CYAN);
        badgePanel.add(badgeLabel);
        topRow.add(badgePanel);

        // Player Tag
        JPanel playerTag = new UIComponents.RoundedCardPanel(12, new Color(30, 41, 59, 180), UIComponents.Colors.CARD_BORDER);
        playerTag.setLayout(new FlowLayout(FlowLayout.CENTER, 8, 3));
        playerTag.setCursor(new Cursor(Cursor.HAND_CURSOR));
        playerBadgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        playerBadgeLabel.setForeground(UIComponents.Colors.TEXT_WHITE);
        playerBadgeLabel.setText("👤 " + player1Name + " (Click to switch)");
        playerTag.add(playerBadgeLabel);
        playerTag.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                promptSelectOrAddPlayer();
            }
        });
        topRow.add(playerTag);

        // Add Player Quick Button
        JButton addPlayerBtn = new JButton("+ Add Player");
        addPlayerBtn.setFont(new Font("Segoe UI", Font.BOLD, 10));
        addPlayerBtn.setBackground(new Color(99, 102, 241, 60));
        addPlayerBtn.setForeground(UIComponents.Colors.TEXT_WHITE);
        addPlayerBtn.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));
        addPlayerBtn.setFocusPainted(false);
        addPlayerBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addPlayerBtn.addActionListener(e -> promptAddNewPlayer());
        topRow.add(addPlayerBtn);

        // Main Title
        JLabel titleLabel = new JLabel("NUMBER GUESSING GAME");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(UIComponents.Colors.TEXT_WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Subtitle
        JLabel subtitleLabel = new JLabel("Think smart. Guess right. Beat your best!");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(UIComponents.Colors.TEXT_MUTED);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(topRow);
        headerPanel.add(Box.createVerticalStrut(8));
        headerPanel.add(titleLabel);
        headerPanel.add(Box.createVerticalStrut(4));
        headerPanel.add(subtitleLabel);
        headerPanel.add(Box.createVerticalStrut(6));

        JPanel masteryPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        masteryPanel.setOpaque(false);
        rankStreakLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        rankStreakLabel.setForeground(UIComponents.Colors.ACCENT_PURPLE);
        masteryPanel.add(rankStreakLabel);
        headerPanel.add(masteryPanel);

        return headerPanel;
    }

    private JPanel createModeSelectorSection() {
        UIComponents.RoundedCardPanel panel = new UIComponents.RoundedCardPanel(16, 
                new Color(20, 26, 48, 190), UIComponents.Colors.CARD_BORDER);
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 14, 6));
        panel.setMaximumSize(new Dimension(740, 52));
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel modeLabel = new JLabel("Game Mode:");
        modeLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        modeLabel.setForeground(UIComponents.Colors.ACCENT_CYAN);
        panel.add(modeLabel);

        soloModeBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        versusModeBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        soloModeBtn.setBorder(new EmptyBorder(6, 16, 6, 16));
        versusModeBtn.setBorder(new EmptyBorder(6, 16, 6, 16));

        panel.add(soloModeBtn);
        panel.add(versusModeBtn);

        return panel;
    }

    private JPanel createDifficultySection() {
        UIComponents.RoundedCardPanel panel = new UIComponents.RoundedCardPanel(16, 
                new Color(30, 41, 59, 160), UIComponents.Colors.CARD_BORDER);
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 14, 8));
        panel.setMaximumSize(new Dimension(740, 56));
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel diffLabel = new JLabel("Difficulty:");
        diffLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        diffLabel.setForeground(UIComponents.Colors.TEXT_MUTED);
        panel.add(diffLabel);

        easyBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        medBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        hardBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));

        easyBtn.setBorder(new EmptyBorder(6, 14, 6, 14));
        medBtn.setBorder(new EmptyBorder(6, 14, 6, 14));
        hardBtn.setBorder(new EmptyBorder(6, 14, 6, 14));

        panel.add(easyBtn);
        panel.add(medBtn);
        panel.add(hardBtn);

        return panel;
    }

    private JPanel createGameCard() {
        UIComponents.RoundedCardPanel card = new UIComponents.RoundedCardPanel(20);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(18, 24, 18, 24));
        card.setMaximumSize(new Dimension(740, 430));
        card.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 1. Target Range & Attempts Row
        JPanel rangeRow = new JPanel(new BorderLayout());
        rangeRow.setOpaque(false);
        rangeCardLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        rangeCardLabel.setForeground(UIComponents.Colors.ACCENT_CYAN);
        rangeRow.add(rangeCardLabel, BorderLayout.WEST);

        attemptsLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        attemptsLabel.setForeground(UIComponents.Colors.TEXT_WHITE);
        attemptsLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        rangeRow.add(attemptsLabel, BorderLayout.EAST);

        card.add(rangeRow);
        card.add(Box.createVerticalStrut(10));

        // 2. Versus Turn Indicator Banner (Shown in Duel Mode)
        duelTurnBadgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        duelTurnBadgeLabel.setForeground(new Color(251, 146, 60));
        duelTurnBadgeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        duelTurnBadgeLabel.setVisible(false);
        card.add(duelTurnBadgeLabel);
        card.add(Box.createVerticalStrut(6));

        // 3. Attempts Progress Bar
        attemptsProgressBar.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(attemptsProgressBar);
        card.add(Box.createVerticalStrut(12));

        // 4. Binary Search Space Advisor & Proximity Radar
        JPanel advisorCard = new UIComponents.RoundedCardPanel(10, new Color(15, 23, 42, 180), UIComponents.Colors.CARD_BORDER);
        advisorCard.setLayout(new BorderLayout(12, 0));
        advisorCard.setBorder(new EmptyBorder(6, 12, 6, 12));
        advisorLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        advisorLabel.setForeground(UIComponents.Colors.TEXT_MUTED);
        advisorCard.add(advisorLabel, BorderLayout.WEST);

        proximityLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        proximityLabel.setForeground(UIComponents.Colors.ACCENT_CYAN);
        advisorCard.add(proximityLabel, BorderLayout.EAST);
        card.add(advisorCard);
        card.add(Box.createVerticalStrut(14));

        // 5. Guess Input Row with Hint Button
        JPanel inputRow = new JPanel(new GridBagLayout());
        inputRow.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();

        guessInput.setPreferredSize(new Dimension(240, 48));
        submitButton.setPreferredSize(new Dimension(160, 48));
        hintButton.setPreferredSize(new Dimension(95, 48));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 0, 8);
        inputRow.add(guessInput, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(0, 0, 0, 8);
        inputRow.add(submitButton, gbc);

        gbc.gridx = 2;
        gbc.insets = new Insets(0, 0, 0, 0);
        inputRow.add(hintButton, gbc);

        card.add(inputRow);
        card.add(Box.createVerticalStrut(14));

        // 6. Dynamic Feedback Badge
        feedbackPanel.setOpaque(false);
        feedbackPanel.setLayout(new BorderLayout(12, 0));
        feedbackPanel.setBorder(new EmptyBorder(10, 14, 10, 14));

        feedbackIconLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        feedbackIconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        feedbackPanel.add(feedbackIconLabel, BorderLayout.WEST);

        feedbackTextLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        feedbackTextLabel.setForeground(UIComponents.Colors.TEXT_WHITE);
        feedbackPanel.add(feedbackTextLabel, BorderLayout.CENTER);

        UIComponents.RoundedCardPanel feedbackWrapper = new UIComponents.RoundedCardPanel(12, 
                new Color(30, 41, 59, 180), UIComponents.Colors.CARD_BORDER);
        feedbackWrapper.setLayout(new BorderLayout());
        feedbackWrapper.add(feedbackPanel, BorderLayout.CENTER);
        feedbackWrapper.setMaximumSize(new Dimension(700, 52));

        card.add(feedbackWrapper);
        card.add(Box.createVerticalStrut(10));

        // 7. Guesses History Row
        JPanel historyRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        historyRow.setOpaque(false);

        guessesHistoryLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        guessesHistoryLabel.setForeground(UIComponents.Colors.TEXT_MUTED);
        guessesHistoryLabel.setText("Guesses so far: None");
        historyRow.add(guessesHistoryLabel);

        card.add(historyRow);

        return card;
    }

    private JPanel createStatsCard() {
        UIComponents.RoundedCardPanel card = new UIComponents.RoundedCardPanel(16);
        card.setLayout(new GridLayout(1, 4, 12, 0));
        card.setBorder(new EmptyBorder(14, 18, 14, 18));
        card.setMaximumSize(new Dimension(740, 90));
        card.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(createStatTile("CURRENT ROUND", currentScoreValueLabel, UIComponents.Colors.ACCENT_CYAN));
        card.add(createStatTile("SESSION BEST", bestScoreValueLabel, UIComponents.Colors.WARNING_TEXT));
        card.add(createStatTile("WIN RATE", winRateValueLabel, UIComponents.Colors.SUCCESS_TEXT));
        card.add(createStatTile("GAMES PLAYED", gamesPlayedValueLabel, UIComponents.Colors.TEXT_WHITE));

        return card;
    }

    private JPanel createStatTile(String title, JLabel valueLabel, Color accentColor) {
        JPanel tile = new JPanel();
        tile.setOpaque(false);
        tile.setLayout(new BoxLayout(tile, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 10));
        titleLabel.setForeground(UIComponents.Colors.TEXT_DIM);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        valueLabel.setForeground(accentColor);
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        tile.add(titleLabel);
        tile.add(Box.createVerticalStrut(4));
        tile.add(valueLabel);

        return tile;
    }

    private JPanel createBottomControls() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(740, 52));
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);

        playAgainBtn.setPreferredSize(new Dimension(150, 42));
        leaderboardBtn.setPreferredSize(new Dimension(150, 42));
        exportReportBtn.setPreferredSize(new Dimension(160, 42));
        exitBtn.setPreferredSize(new Dimension(90, 42));

        panel.add(playAgainBtn);
        panel.add(leaderboardBtn);
        panel.add(exportReportBtn);
        panel.add(exitBtn);

        return panel;
    }

    // ==========================================
    // CONTROLLER & EVENT HANDLING
    // ==========================================

    private void setupEventHandlers() {
        soloModeBtn.addActionListener(e -> setGameMode(GameMode.SOLO));
        versusModeBtn.addActionListener(e -> setGameMode(GameMode.VERSUS_DUEL));

        submitButton.addActionListener(e -> processCurrentGuess());
        guessInput.addActionListener(e -> processCurrentGuess());
        hintButton.addActionListener(e -> provideHint());

        easyBtn.addActionListener(e -> changeDifficulty(Difficulty.EASY));
        medBtn.addActionListener(e -> changeDifficulty(Difficulty.MEDIUM));
        hardBtn.addActionListener(e -> changeDifficulty(Difficulty.HARD));

        playAgainBtn.addActionListener(e -> handleReplay());
        leaderboardBtn.addActionListener(e -> showLeaderboardDialog());
        exportReportBtn.addActionListener(e -> handleExportReport());
        exitBtn.addActionListener(e -> handleExit());

        // Keyboard Shortcut: Ctrl+N to restart
        rootPane.registerKeyboardAction(e -> handleReplay(),
                KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    private void setGameMode(GameMode mode) {
        if (this.currentMode == mode) return;
        this.currentMode = mode;
        if (mode == GameMode.SOLO) {
            soloModeBtn.setButtonStyle(UIComponents.ModernButton.ButtonStyle.PRIMARY);
            versusModeBtn.setButtonStyle(UIComponents.ModernButton.ButtonStyle.SECONDARY);
            duelTurnBadgeLabel.setVisible(false);
            playerBadgeLabel.setText("👤 " + player1Name + " (Click to switch)");
            hintButton.setEnabled(true);
        } else {
            soloModeBtn.setButtonStyle(UIComponents.ModernButton.ButtonStyle.SECONDARY);
            versusModeBtn.setButtonStyle(UIComponents.ModernButton.ButtonStyle.PRIMARY);
            duelTurnBadgeLabel.setVisible(true);
            promptConfigureDuelPlayers();
            startNewDuelMatch();
        }
        handleReplay();
    }

    private void promptConfigureDuelPlayers() {
        List<String> players = playerManager.getPlayers();
        if (players.size() < 2) {
            promptAddNewPlayer();
            players = playerManager.getPlayers();
        }

        String[] playerArray = players.toArray(new String[0]);
        JComboBox<String> p1Box = new JComboBox<>(playerArray);
        JComboBox<String> p2Box = new JComboBox<>(playerArray);
        p1Box.setSelectedItem(player1Name);
        if (players.size() > 1) {
            p2Box.setSelectedItem(player2Name.equals(player1Name) ? players.get(1) : player2Name);
        }

        JPanel panel = new JPanel(new GridLayout(2, 2, 8, 8));
        panel.add(new JLabel("Player 1:"));
        panel.add(p1Box);
        panel.add(new JLabel("Player 2:"));
        panel.add(p2Box);

        int result = JOptionPane.showConfirmDialog(this, panel, "⚔️ Configure 2-Player Duel",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            player1Name = (String) p1Box.getSelectedItem();
            player2Name = (String) p2Box.getSelectedItem();
            if (player1Name.equals(player2Name)) {
                player2Name = player2Name + " (2)";
                playerManager.addPlayer(player2Name);
            }
        }
    }

    private void promptSelectOrAddPlayer() {
        List<String> players = playerManager.getPlayers();
        String[] options = new String[players.size() + 1];
        for (int i = 0; i < players.size(); i++) options[i] = players.get(i);
        options[players.size()] = "➕ Add New Player Profile...";

        String selected = (String) JOptionPane.showInputDialog(
                this,
                "Select player profile or create a new one:",
                "Player Profile Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                player1Name
        );

        if (selected != null) {
            if (selected.equals("➕ Add New Player Profile...")) {
                promptAddNewPlayer();
            } else {
                player1Name = selected;
                playerManager.setActivePlayer(player1Name);
                playerBadgeLabel.setText("👤 " + player1Name + " (Click to switch)");
            }
        }
    }

    private void promptAddNewPlayer() {
        String input = JOptionPane.showInputDialog(this, 
                "Enter new player / candidate name for leaderboard & duels:", 
                "Add New Player", JOptionPane.PLAIN_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            String name = input.trim();
            playerManager.addPlayer(name);
            player1Name = name;
            playerBadgeLabel.setText("👤 " + player1Name + " (Click to switch)");
            JOptionPane.showMessageDialog(this, "Player profile '" + name + "' registered successfully!",
                    "Profile Added", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void startNewDuelMatch() {
        Difficulty diff = gameLogic.getDifficulty();
        duelLogic = new VersusDuelLogic(player1Name, player2Name, diff);
        duelTurnBadgeLabel.setText(String.format("👉 %s's Turn (P1: 0 tries | P2: 0 tries)", duelLogic.getCurrentActivePlayerName()));
        playerBadgeLabel.setText(String.format("⚔️ %s vs %s", player1Name, player2Name));
        hintButton.setEnabled(false); // Hints disabled in competitive head-to-head duel
    }

    private void processCurrentGuess() {
        if (currentMode == GameMode.SOLO) {
            processSoloGuess();
        } else {
            processDuelGuess();
        }
    }

    private void processDuelGuess() {
        if (duelLogic.isDuelOver()) return;

        String rawInput = guessInput.getText();
        VersusDuelLogic.DuelGuessResult result = duelLogic.submitDuelGuess(rawInput);

        if (result.getOutcome() == VersusDuelLogic.DuelGuessResult.Outcome.INVALID_INPUT) {
            feedbackIconLabel.setText("[WARN]");
            feedbackTextLabel.setForeground(UIComponents.Colors.WARNING_TEXT);
            feedbackTextLabel.setText(result.getMessage());
            return;
        }

        guessInput.setText("");

        // Update advisor & bounds for duel
        int low = duelLogic.getCurrentLowBound();
        int high = duelLogic.getCurrentHighBound();
        int optimal = (low + high) / 2;
        advisorLabel.setText(String.format("🔍 Active Space: [%d to %d]  |  💡 Optimal Deduction Guess: %d",
                low, high, optimal));

        // Proximity radar relative to guess
        int sec = duelLogic.getSecretNumberIfEnded();
        if (sec > 0) {
            proximityLabel.setText("🎯 BULLSEYE HIT!");
        } else {
            int guessVal = result.getGuess();
            int diff = Math.abs(guessVal - optimal);
            proximityLabel.setText(diff <= 5 ? "🔥 Hot Duel Guess!" : "🧭 Space Narrowed");
        }

        // Guesses history
        List<String> log = duelLogic.getDuelLog();
        if (!log.isEmpty()) {
            guessesHistoryLabel.setText("Duel Log: " + log.get(log.size() - 1));
        }

        int maxPerPlayer = gameLogic.getDifficulty().getMaxAttempts();
        int activeTries = (duelLogic.getCurrentTurn() == 1) ? result.getP1Tries() : result.getP2Tries();
        int remAttempts = Math.max(0, maxPerPlayer - activeTries);
        attemptsLabel.setText(String.format("P1: %d tries | P2: %d tries", result.getP1Tries(), result.getP2Tries()));
        attemptsProgressBar.setAttempts(remAttempts, maxPerPlayer);

        if (result.isDuelEnded()) {
            guessInput.setEnabled(false);
            submitButton.setEnabled(false);

            if (result.getOutcome() == VersusDuelLogic.DuelGuessResult.Outcome.WINNER_FOUND) {
                confettiOverlay.startCelebration();
                feedbackIconLabel.setText("[CHAMPION]");
                feedbackTextLabel.setForeground(UIComponents.Colors.SUCCESS_TEXT);
                feedbackTextLabel.setText(result.getMessage());
                duelTurnBadgeLabel.setText("👑 DUEL CHAMPION: " + result.getChampionName().toUpperCase() + "!");

                // Persist duel record
                ScorePersistence.saveDuelRecord(
                        player1Name,
                        player2Name,
                        result.getChampionName(),
                        duelLogic.getWinningAttempts(),
                        duelLogic.getMatchDurationSeconds(),
                        gameLogic.getDifficulty().getDisplayName()
                );
            } else {
                feedbackIconLabel.setText("[TIE]");
                feedbackTextLabel.setForeground(UIComponents.Colors.DANGER_TEXT);
                feedbackTextLabel.setText(result.getMessage());
                duelTurnBadgeLabel.setText("🤝 MATCH TIED - BOTH EXHAUSTED ATTEMPTS");
            }
            playAgainBtn.requestFocusInWindow();
        } else {
            feedbackIconLabel.setText("[DUEL]");
            feedbackTextLabel.setForeground(UIComponents.Colors.INFO_TEXT);
            feedbackTextLabel.setText(result.getMessage());
            duelTurnBadgeLabel.setText(String.format("👉 %s's Turn (P1: %d | P2: %d)", 
                    duelLogic.getCurrentActivePlayerName(), result.getP1Tries(), result.getP2Tries()));
            guessInput.requestFocusInWindow();
        }
    }

    private void provideHint() {
        if (currentMode == GameMode.VERSUS_DUEL) {
            JOptionPane.showMessageDialog(this, "Hints are disabled during 2-Player Head-to-Head Duels to ensure fair competition!",
                    "Duel Mode Rules", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (gameLogic.isGameOver()) {
            return;
        }
        String hint = gameLogic.getNextHint();
        feedbackIconLabel.setText("💡");
        feedbackTextLabel.setForeground(UIComponents.Colors.WARNING_TEXT);
        feedbackTextLabel.setText(hint + " (-50 pts bonus penalty on win)");
        guessInput.requestFocusInWindow();
    }

    private void processSoloGuess() {
        if (gameLogic.isGameOver()) {
            return;
        }

        String rawInput = guessInput.getText();
        GuessResult result = gameLogic.submitGuess(rawInput);

        // Update feedback, advisor, and history
        updateFeedback(result);

        if (!result.isInputError()) {
            guessInput.setText("");
            updateGuessesHistory();
            updateAdvisor();
            proximityLabel.setText(gameLogic.getProximityIndicator(result.getGuess()));
        }

        attemptsProgressBar.setAttempts(result.getAttemptsRemaining(), gameLogic.getMaxAttempts());
        attemptsLabel.setText(String.format("Attempts: %d / %d", 
                result.getAttemptsRemaining(), gameLogic.getMaxAttempts()));

        if (result.isRoundOver()) {
            guessInput.setEnabled(false);
            submitButton.setEnabled(false);
            hintButton.setEnabled(false);

            if (result.isRoundWon()) {
                winStreak++;
                confettiOverlay.startCelebration();
            } else {
                winStreak = 0;
            }

            // Record session stats
            gameStats.recordRound(result.isRoundWon(), result.getPointsAwarded());
            syncStatsUI();

            // Persist match record locally to CSV
            GameRecord record = new GameRecord(
                    player1Name,
                    gameLogic.getDifficulty().getDisplayName(),
                    result.getPointsAwarded(),
                    result.getAttemptsUsed(),
                    gameLogic.getMaxAttempts(),
                    result.isRoundWon()
            );
            sessionRecords.add(record);
            ScorePersistence.saveRecord(record);

            playAgainBtn.requestFocusInWindow();
        } else {
            guessInput.requestFocusInWindow();
        }
    }

    private void updateFeedback(GuessResult result) {
        String msg = result.getMessage();
        switch (result.getStatus()) {
            case TOO_HIGH:
                feedbackIconLabel.setText("[HIGH]");
                feedbackTextLabel.setForeground(UIComponents.Colors.WARNING_TEXT);
                feedbackTextLabel.setText(msg);
                break;

            case TOO_LOW:
                feedbackIconLabel.setText("[LOW]");
                feedbackTextLabel.setForeground(UIComponents.Colors.INFO_TEXT);
                feedbackTextLabel.setText(msg);
                break;

            case CORRECT:
                feedbackIconLabel.setText("[WIN]");
                feedbackTextLabel.setForeground(UIComponents.Colors.SUCCESS_TEXT);
                feedbackTextLabel.setText(msg);
                break;

            case GAME_OVER_LOST:
                feedbackIconLabel.setText("[LOST]");
                feedbackTextLabel.setForeground(UIComponents.Colors.DANGER_TEXT);
                feedbackTextLabel.setText(msg);
                break;

            case INVALID_EMPTY:
            case INVALID_NON_NUMERIC:
            case OUT_OF_RANGE:
            case ALREADY_GUESSED:
                feedbackIconLabel.setText("[WARN]");
                feedbackTextLabel.setForeground(UIComponents.Colors.WARNING_TEXT);
                feedbackTextLabel.setText(msg);
                break;
        }
    }

    private void updateAdvisor() {
        int low = gameLogic.getCurrentLowBound();
        int high = gameLogic.getCurrentHighBound();
        int remainingCandidates = gameLogic.getRemainingSearchSpace();
        int optimal = gameLogic.getOptimalBinarySearchGuess();

        advisorLabel.setText(String.format("🔍 Active Space: [%d to %d] (%d candidates left)  |  💡 Binary Search Optimal Guess: %d",
                low, high, remainingCandidates, optimal));
    }

    private void updateGuessesHistory() {
        List<Integer> history = gameLogic.getGuessesHistory();
        if (history.isEmpty()) {
            guessesHistoryLabel.setText("Guesses so far: None");
            return;
        }

        StringBuilder sb = new StringBuilder("Guesses so far: ");
        for (int i = 0; i < history.size(); i++) {
            sb.append(history.get(i));
            if (i < history.size() - 1) {
                sb.append("  •  ");
            }
        }
        guessesHistoryLabel.setText(sb.toString());
    }

    private void changeDifficulty(Difficulty diff) {
        if (gameLogic.getDifficulty() == diff && !gameLogic.isGameOver() && gameLogic.getAttemptsUsed() == 0) {
            return;
        }

        if (!gameLogic.isGameOver() && gameLogic.getAttemptsUsed() > 0) {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Changing difficulty will start a new round. Current progress will be reset.\nContinue?",
                    "Confirm Difficulty Change",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );
            if (choice != JOptionPane.YES_OPTION) {
                return;
            }
        }

        updateDifficultyButtons(diff);
        confettiOverlay.stopCelebration();
        gameLogic.startNewGame(diff);
        if (currentMode == GameMode.VERSUS_DUEL) {
            startNewDuelMatch();
        }
        syncGameUI();
        guessInput.requestFocusInWindow();
    }

    private void updateDifficultyButtons(Difficulty active) {
        easyBtn.setButtonStyle(active == Difficulty.EASY ? UIComponents.ModernButton.ButtonStyle.PRIMARY : UIComponents.ModernButton.ButtonStyle.SECONDARY);
        medBtn.setButtonStyle(active == Difficulty.MEDIUM ? UIComponents.ModernButton.ButtonStyle.PRIMARY : UIComponents.ModernButton.ButtonStyle.SECONDARY);
        hardBtn.setButtonStyle(active == Difficulty.HARD ? UIComponents.ModernButton.ButtonStyle.PRIMARY : UIComponents.ModernButton.ButtonStyle.SECONDARY);
    }

    private void handleReplay() {
        confettiOverlay.stopCelebration();
        gameLogic.startNewGame(gameLogic.getDifficulty());
        if (currentMode == GameMode.VERSUS_DUEL) {
            startNewDuelMatch();
        }
        syncGameUI();
        guessInput.setText("");
        guessInput.setEnabled(true);
        submitButton.setEnabled(true);
        hintButton.setEnabled(currentMode == GameMode.SOLO);
        guessInput.requestFocusInWindow();
    }

    private void showLeaderboardDialog() {
        List<GameRecord> soloRecords = ScorePersistence.loadRecords();
        List<String[]> duelRecords = ScorePersistence.loadDuelRecords();

        JDialog dialog = new JDialog(this, "🏆 Hall of Fame & Leaderboards", true);
        dialog.setSize(720, 500);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(UIComponents.Colors.BG_TOP);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel title = new JLabel("🏆 Leaderboards & Competition History", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(UIComponents.Colors.TEXT_WHITE);
        panel.add(title, BorderLayout.NORTH);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(new Color(20, 26, 48));
        tabbedPane.setForeground(UIComponents.Colors.TEXT_WHITE);

        // Tab 1: Solo Rankings
        String[] soloCols = {"Rank", "Player", "Difficulty", "Score", "Tries", "Result", "Date"};
        DefaultTableModel soloModel = new DefaultTableModel(soloCols, 0);
        for (int i = 0; i < soloRecords.size(); i++) {
            GameRecord r = soloRecords.get(i);
            soloModel.addRow(new Object[]{
                    "#" + (i + 1),
                    r.getPlayerName(),
                    r.getDifficulty(),
                    r.getScore() + " pts",
                    r.getAttemptsUsed() + "/" + r.getMaxAttempts(),
                    r.isWon() ? "WON" : "LOST",
                    r.getTimestamp()
            });
        }
        JTable soloTable = createStyledTable(soloModel);
        tabbedPane.addTab("🎯 Solo High Scores", new JScrollPane(soloTable));

        // Tab 2: 2-Player Duels
        String[] duelCols = {"Match #", "Player 1", "Player 2", "Champion 👑", "Tries", "Time (s)", "Diff", "Date"};
        DefaultTableModel duelModel = new DefaultTableModel(duelCols, 0);
        for (int i = 0; i < duelRecords.size(); i++) {
            String[] d = duelRecords.get(i);
            duelModel.addRow(new Object[]{
                    "#" + (i + 1),
                    d[0],
                    d[1],
                    d[2],
                    d[3],
                    d[4] + "s",
                    d[5],
                    d[6]
            });
        }
        JTable duelTable = createStyledTable(duelModel);
        tabbedPane.addTab("⚔️ 2-Player Duel Battles", new JScrollPane(duelTable));

        panel.add(tabbedPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        bottomPanel.setOpaque(false);

        JButton addPBtn = new JButton("+ Add Player");
        addPBtn.addActionListener(e -> {
            promptAddNewPlayer();
            dialog.dispose();
            showLeaderboardDialog();
        });
        bottomPanel.add(addPBtn);

        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> dialog.dispose());
        bottomPanel.add(closeBtn);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }

    private JTable createStyledTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setFillsViewportHeight(true);
        table.setBackground(UIComponents.Colors.CARD_BG);
        table.setForeground(UIComponents.Colors.TEXT_WHITE);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(24);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBackground(new Color(30, 41, 59));
        table.getTableHeader().setForeground(UIComponents.Colors.ACCENT_CYAN);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        for (int c = 0; c < table.getColumnCount(); c++) {
            table.getColumnModel().getColumn(c).setCellRenderer(center);
        }
        return table;
    }

    private void handleExportReport() {
        File file = ScorePersistence.exportPerformanceReport(player1Name, gameStats, sessionRecords);
        JOptionPane.showMessageDialog(this,
                "✅ Internship Performance Report successfully generated!\nSaved to: " + file.getAbsolutePath(),
                "Report Exported",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleExit() {
        int choice = JOptionPane.showConfirmDialog(
                this,
                String.format("Session Summary for %s:\n• Games: %d\n• Wins: %d\n• Best Score: %d pts\n\nAre you sure you want to exit?",
                        player1Name, gameStats.getTotalGamesPlayed(), gameStats.getTotalWins(), gameStats.getBestScore()),
                "Exit Game",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (choice == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }

    private void syncGameUI() {
        Difficulty diff = gameLogic.getDifficulty();

        rangeCardLabel.setText(String.format("Target Range: %d - %d", diff.getMinRange(), diff.getMaxRange()));
        if (currentMode == GameMode.SOLO) {
            attemptsLabel.setText(String.format("Attempts: %d / %d", 
                    gameLogic.getRemainingAttempts(), gameLogic.getMaxAttempts()));
            attemptsProgressBar.setAttempts(gameLogic.getRemainingAttempts(), gameLogic.getMaxAttempts());

            feedbackIconLabel.setText("[INFO]");
            feedbackTextLabel.setForeground(UIComponents.Colors.TEXT_MUTED);
            feedbackTextLabel.setText(String.format("Guess a secret number between %d and %d! You have %d attempts.",
                    diff.getMinRange(), diff.getMaxRange(), diff.getMaxAttempts()));
        } else {
            attemptsLabel.setText(String.format("Attempts Per Player: %d", diff.getMaxAttempts()));
            attemptsProgressBar.setAttempts(diff.getMaxAttempts(), diff.getMaxAttempts());
            feedbackIconLabel.setText("[DUEL]");
            feedbackTextLabel.setForeground(UIComponents.Colors.INFO_TEXT);
            feedbackTextLabel.setText(String.format("⚔️ Head-to-Head Duel! %s and %s take turns to guess the secret number first!",
                    player1Name, player2Name));
        }

        proximityLabel.setText("🧭 Radar: Awaiting guess...");
        updateAdvisor();
        updateGuessesHistory();
        syncStatsUI();
    }

    private void syncStatsUI() {
        currentScoreValueLabel.setText(gameLogic.getCurrentRoundScore() + " pts");
        bestScoreValueLabel.setText(gameStats.getBestScore() + " pts");
        winRateValueLabel.setText(gameStats.getFormattedWinPercentage());
        gamesPlayedValueLabel.setText(String.format("%d (%dW / %dL)",
                gameStats.getTotalGamesPlayed(), gameStats.getTotalWins(), gameStats.getTotalLosses()));

        String rankTitle = "Novice Guesser";
        if (gameStats.getBestScore() >= 1500) rankTitle = "Grandmaster Algorithmist";
        else if (gameStats.getBestScore() >= 900) rankTitle = "Binary Detective";
        else if (gameStats.getBestScore() >= 400) rankTitle = "Search Apprentice";
        rankStreakLabel.setText(String.format("🎖️ Rank: %s  |  🔥 Streak: %d", rankTitle, winStreak));
    }

    public static void main(String[] args) {
        Main.main(args);
    }
}
