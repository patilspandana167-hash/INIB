/**
 * Difficulty Enum for the Number Guessing Game.
 * Configures the target number range, allowed attempts, and scoring multiplier.
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public enum Difficulty {
    EASY("Easy", 1, 50, 10, 1.0, "Range: 1 - 50 | 10 Attempts"),
    MEDIUM("Medium", 1, 100, 7, 1.5, "Range: 1 - 100 | 7 Attempts (Standard)"),
    HARD("Hard", 1, 200, 6, 2.5, "Range: 1 - 200 | 6 Attempts (Challenging)");

    private final String displayName;
    private final int minRange;
    private final int maxRange;
    private final int maxAttempts;
    private final double scoreMultiplier;
    private final String description;

    Difficulty(String displayName, int minRange, int maxRange, int maxAttempts, double scoreMultiplier, String description) {
        this.displayName = displayName;
        this.minRange = minRange;
        this.maxRange = maxRange;
        this.maxAttempts = maxAttempts;
        this.scoreMultiplier = scoreMultiplier;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getMinRange() {
        return minRange;
    }

    public int getMaxRange() {
        return maxRange;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    public double getScoreMultiplier() {
        return scoreMultiplier;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
