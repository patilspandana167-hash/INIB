import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents a completed game session record for persistent leaderboard tracking.
 * Can be exported to CSV, displayed in the leaderboard, and included in reports.
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public class GameRecord {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final String playerName;
    private final String difficulty;
    private final int score;
    private final int attemptsUsed;
    private final int maxAttempts;
    private final boolean won;
    private final String timestamp;

    public GameRecord(String playerName, String difficulty, int score, int attemptsUsed, int maxAttempts, boolean won) {
        this(playerName, difficulty, score, attemptsUsed, maxAttempts, won, LocalDateTime.now().format(FORMATTER));
    }

    public GameRecord(String playerName, String difficulty, int score, int attemptsUsed, int maxAttempts, boolean won, String timestamp) {
        this.playerName = playerName == null || playerName.trim().isEmpty() ? "Player 1" : playerName.trim();
        this.difficulty = difficulty;
        this.score = score;
        this.attemptsUsed = attemptsUsed;
        this.maxAttempts = maxAttempts;
        this.won = won;
        this.timestamp = timestamp;
    }

    public String getPlayerName() {
        return playerName;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getScore() {
        return score;
    }

    public int getAttemptsUsed() {
        return attemptsUsed;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    public boolean isWon() {
        return won;
    }

    public String getTimestamp() {
        return timestamp;
    }

    /**
     * Converts to CSV format for disk storage.
     */
    public String toCsvLine() {
        return String.format("%s,%s,%d,%d,%d,%b,%s",
                escapeCsv(playerName), difficulty, score, attemptsUsed, maxAttempts, won, timestamp);
    }

    /**
     * Parses from CSV format.
     */
    public static GameRecord fromCsvLine(String line) {
        if (line == null || line.trim().isEmpty()) return null;
        String[] parts = line.split(",", -1);
        if (parts.length < 7) return null;
        try {
            String name = parts[0].trim();
            String diff = parts[1].trim();
            int score = Integer.parseInt(parts[2].trim());
            int used = Integer.parseInt(parts[3].trim());
            int max = Integer.parseInt(parts[4].trim());
            boolean won = Boolean.parseBoolean(parts[5].trim());
            String time = parts[6].trim();
            return new GameRecord(name, diff, score, used, max, won, time);
        } catch (Exception e) {
            return null;
        }
    }

    private static String escapeCsv(String val) {
        return val.replace(",", " ");
    }
}
