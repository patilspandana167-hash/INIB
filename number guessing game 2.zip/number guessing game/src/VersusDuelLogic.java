import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Handles 2-Player Competitive Versus Mode mechanics.
 * In a turn-based speed and deduction race, two players alternate turns
 * attempting to guess the secret number first.
 * Tracks attempts per player, turn timers, and determines the champion.
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public class VersusDuelLogic {

    private String player1Name;
    private String player2Name;
    private Difficulty difficulty;
    private int secretNumber;
    private int currentTurn; // 1 for Player 1, 2 for Player 2
    private int player1Attempts;
    private int player2Attempts;
    private long matchStartTime;
    private long matchEndTime;
    private boolean duelOver;
    private String winnerName;
    private int winningAttempts;
    private double matchDurationSeconds;
    private int currentLowBound;
    private int currentHighBound;
    private final List<String> duelLog;

    public VersusDuelLogic(String player1Name, String player2Name, Difficulty difficulty) {
        this.player1Name = (player1Name == null || player1Name.trim().isEmpty()) ? "Player 1" : player1Name.trim();
        this.player2Name = (player2Name == null || player2Name.trim().isEmpty()) ? "Player 2" : player2Name.trim();
        this.difficulty = difficulty != null ? difficulty : Difficulty.MEDIUM;
        this.duelLog = new ArrayList<>();
        startNewDuel(this.player1Name, this.player2Name, this.difficulty);
    }

    public void startNewDuel(String p1, String p2, Difficulty diff) {
        this.player1Name = (p1 == null || p1.trim().isEmpty()) ? "Player 1" : p1.trim();
        this.player2Name = (p2 == null || p2.trim().isEmpty()) ? "Player 2" : p2.trim();
        this.difficulty = diff != null ? diff : Difficulty.MEDIUM;
        this.currentTurn = 1; // Player 1 starts
        this.player1Attempts = 0;
        this.player2Attempts = 0;
        this.duelOver = false;
        this.winnerName = null;
        this.winningAttempts = 0;
        this.matchDurationSeconds = 0;
        this.currentLowBound = this.difficulty.getMinRange();
        this.currentHighBound = this.difficulty.getMaxRange();
        this.duelLog.clear();

        // Secret number generated
        this.secretNumber = ThreadLocalRandom.current().nextInt(
                this.difficulty.getMinRange(),
                this.difficulty.getMaxRange() + 1
        );

        this.matchStartTime = System.currentTimeMillis();
    }

    public static class DuelGuessResult {
        public enum Outcome {
            TOO_HIGH,
            TOO_LOW,
            WINNER_FOUND,
            TIE_EXHAUSTED,
            INVALID_INPUT
        }

        private final Outcome outcome;
        private final String message;
        private final String activePlayer;
        private final String nextPlayer;
        private final int guess;
        private final int p1Tries;
        private final int p2Tries;
        private final boolean duelEnded;
        private final String championName;

        public DuelGuessResult(Outcome outcome, String message, String activePlayer, 
                               String nextPlayer, int guess, int p1Tries, int p2Tries, 
                               boolean duelEnded, String championName) {
            this.outcome = outcome;
            this.message = message;
            this.activePlayer = activePlayer;
            this.nextPlayer = nextPlayer;
            this.guess = guess;
            this.p1Tries = p1Tries;
            this.p2Tries = p2Tries;
            this.duelEnded = duelEnded;
            this.championName = championName;
        }

        public Outcome getOutcome() { return outcome; }
        public String getMessage() { return message; }
        public String getActivePlayer() { return activePlayer; }
        public String getNextPlayer() { return nextPlayer; }
        public int getGuess() { return guess; }
        public int getP1Tries() { return p1Tries; }
        public int getP2Tries() { return p2Tries; }
        public boolean isDuelEnded() { return duelEnded; }
        public String getChampionName() { return championName; }
    }

    public DuelGuessResult submitDuelGuess(String rawInput) {
        if (duelOver) {
            return new DuelGuessResult(
                    DuelGuessResult.Outcome.WINNER_FOUND,
                    "Duel is already over! Champion: " + winnerName,
                    getCurrentActivePlayerName(), getCurrentActivePlayerName(),
                    0, player1Attempts, player2Attempts, true, winnerName
            );
        }

        if (rawInput == null || rawInput.trim().isEmpty()) {
            return new DuelGuessResult(
                    DuelGuessResult.Outcome.INVALID_INPUT,
                    "Please enter a number guess.",
                    getCurrentActivePlayerName(), getCurrentActivePlayerName(),
                    0, player1Attempts, player2Attempts, false, null
            );
        }

        int guess;
        try {
            guess = Integer.parseInt(rawInput.trim());
        } catch (NumberFormatException e) {
            return new DuelGuessResult(
                    DuelGuessResult.Outcome.INVALID_INPUT,
                    "Invalid whole number format.",
                    getCurrentActivePlayerName(), getCurrentActivePlayerName(),
                    0, player1Attempts, player2Attempts, false, null
            );
        }

        if (guess < difficulty.getMinRange() || guess > difficulty.getMaxRange()) {
            return new DuelGuessResult(
                    DuelGuessResult.Outcome.INVALID_INPUT,
                    String.format("Guess must be between %d and %d.", difficulty.getMinRange(), difficulty.getMaxRange()),
                    getCurrentActivePlayerName(), getCurrentActivePlayerName(),
                    guess, player1Attempts, player2Attempts, false, null
            );
        }

        // Valid guess: count attempts for current active player
        String activeP = getCurrentActivePlayerName();
        if (currentTurn == 1) {
            player1Attempts++;
        } else {
            player2Attempts++;
        }

        // Check if guess is correct
        if (guess == secretNumber) {
            duelOver = true;
            winnerName = activeP;
            winningAttempts = (currentTurn == 1) ? player1Attempts : player2Attempts;
            matchEndTime = System.currentTimeMillis();
            matchDurationSeconds = Math.max(1.0, (matchEndTime - matchStartTime) / 1000.0);

            String winMsg = String.format("👑 %s WINS THE DUEL! Correctly guessed %d in %d tries (%.1fs)!",
                    winnerName, secretNumber, winningAttempts, matchDurationSeconds);
            duelLog.add(String.format("%s guessed %d -> [WINNER!]", activeP, guess));

            return new DuelGuessResult(
                    DuelGuessResult.Outcome.WINNER_FOUND,
                    winMsg, activeP, activeP, guess,
                    player1Attempts, player2Attempts, true, winnerName
            );
        }

        // If incorrect, update search space bounds
        if (guess > secretNumber) {
            currentHighBound = Math.min(currentHighBound, guess - 1);
            duelLog.add(String.format("%s guessed %d -> [Too High]", activeP, guess));
        } else {
            currentLowBound = Math.max(currentLowBound, guess + 1);
            duelLog.add(String.format("%s guessed %d -> [Too Low]", activeP, guess));
        }

        // Check for max attempts limit (both players exhausted max attempts)
        int maxPerPlayer = difficulty.getMaxAttempts();
        if (player1Attempts >= maxPerPlayer && player2Attempts >= maxPerPlayer) {
            duelOver = true;
            winnerName = "Tie / Both Exhausted";
            matchEndTime = System.currentTimeMillis();
            matchDurationSeconds = Math.max(1.0, (matchEndTime - matchStartTime) / 1000.0);
            return new DuelGuessResult(
                    DuelGuessResult.Outcome.TIE_EXHAUSTED,
                    String.format("Match Tie! Both players used all %d attempts. Secret was %d.", maxPerPlayer, secretNumber),
                    activeP, activeP, guess, player1Attempts, player2Attempts, true, "No Winner (Tie)"
            );
        }

        // Switch turn to the other player
        currentTurn = (currentTurn == 1) ? 2 : 1;
        String nextP = getCurrentActivePlayerName();

        String feedbackMsg = (guess > secretNumber)
                ? String.format("%s guessed %d (Too High!). 👉 It is now %s's turn!", activeP, guess, nextP)
                : String.format("%s guessed %d (Too Low!). 👉 It is now %s's turn!", activeP, guess, nextP);

        return new DuelGuessResult(
                (guess > secretNumber) ? DuelGuessResult.Outcome.TOO_HIGH : DuelGuessResult.Outcome.TOO_LOW,
                feedbackMsg, activeP, nextP, guess, player1Attempts, player2Attempts, false, null
        );
    }

    public String getCurrentActivePlayerName() {
        return (currentTurn == 1) ? player1Name : player2Name;
    }

    public int getCurrentTurn() { return currentTurn; }
    public String getPlayer1Name() { return player1Name; }
    public String getPlayer2Name() { return player2Name; }
    public int getPlayer1Attempts() { return player1Attempts; }
    public int getPlayer2Attempts() { return player2Attempts; }
    public boolean isDuelOver() { return duelOver; }
    public String getWinnerName() { return winnerName; }
    public int getWinningAttempts() { return winningAttempts; }
    public double getMatchDurationSeconds() { return matchDurationSeconds; }
    public int getCurrentLowBound() { return currentLowBound; }
    public int getCurrentHighBound() { return currentHighBound; }
    public int getSecretNumberIfEnded() { return duelOver ? secretNumber : -1; }
    public List<String> getDuelLog() { return duelLog; }
}
