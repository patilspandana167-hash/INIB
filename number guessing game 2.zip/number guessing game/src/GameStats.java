/**
 * Tracks session statistics and performance metrics for the Number Guessing Game.
 * Maintains total rounds, wins, losses, win rate percentage, best score,
 * and cumulative points across the session.
 * 
 * Part of Infobyte Internship Task 1: Number Guessing Game.
 */
public class GameStats {

    private int totalGamesPlayed;
    private int totalWins;
    private int totalLosses;
    private int bestScore;
    private int totalScore;
    private int lastRoundScore;

    public GameStats() {
        reset();
    }

    /**
     * Resets all session metrics back to zero.
     */
    public void reset() {
        this.totalGamesPlayed = 0;
        this.totalWins = 0;
        this.totalLosses = 0;
        this.bestScore = 0;
        this.totalScore = 0;
        this.lastRoundScore = 0;
    }

    /**
     * Records the conclusion of a game round.
     * 
     * @param won True if player correctly guessed the secret number
     * @param roundScore Points earned during this round (0 for loss)
     */
    public void recordRound(boolean won, int roundScore) {
        totalGamesPlayed++;
        lastRoundScore = roundScore;

        if (won) {
            totalWins++;
            totalScore += roundScore;
            if (roundScore > bestScore) {
                bestScore = roundScore;
            }
        } else {
            totalLosses++;
        }
    }

    public int getTotalGamesPlayed() {
        return totalGamesPlayed;
    }

    public int getTotalWins() {
        return totalWins;
    }

    public int getTotalLosses() {
        return totalLosses;
    }

    public int getBestScore() {
        return bestScore;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public int getLastRoundScore() {
        return lastRoundScore;
    }

    /**
     * Calculates the player's win percentage across all concluded rounds.
     * 
     * @return Formatted win rate percentage between 0.0 and 100.0
     */
    public double getWinPercentage() {
        if (totalGamesPlayed == 0) {
            return 0.0;
        }
        return (totalWins * 100.0) / totalGamesPlayed;
    }

    /**
     * Returns a string representation of the win percentage (e.g., "75.0%").
     */
    public String getFormattedWinPercentage() {
        return String.format("%.1f%%", getWinPercentage());
    }
}
